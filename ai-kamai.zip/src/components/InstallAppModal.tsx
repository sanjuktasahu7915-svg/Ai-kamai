import React, { useState } from 'react';
import {
  X,
  Download,
  Smartphone,
  CheckCircle2,
  Share2,
  PlusSquare,
  Sparkles,
  ExternalLink,
  ShieldCheck,
  Zap,
  Check,
  Copy,
} from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface InstallAppModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const InstallAppModal: React.FC<InstallAppModalProps> = ({ isOpen, onClose }) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [activeTab, setActiveTab] = useState<'android' | 'ios' | 'zip'>('android');
  const [copiedLink, setCopiedLink] = useState(false);
  const [isInstalling, setIsInstalling] = useState(false);

  if (!isOpen) return null;

  const currentUrl = window.location.href;

  const handleNativeInstall = async () => {
    setIsInstalling(true);
    try {
      const success = await install();
      if (success) {
        // App installed
      }
    } catch {
      // ignore
    } finally {
      setIsInstalling(false);
    }
  };

  const handleCopyLink = async () => {
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(currentUrl);
      }
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2500);
    } catch {
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2500);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-zinc-900 border border-zinc-700/80 rounded-3xl w-full max-w-md max-h-[92vh] overflow-y-auto shadow-2xl text-white">
        {/* Header with App Icon */}
        <div className="p-4 bg-gradient-to-b from-[#5f259f]/40 to-zinc-900 border-b border-zinc-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="relative w-12 h-12 rounded-2xl bg-gradient-to-tr from-[#5f259f] to-[#ec4899] p-0.5 shadow-lg shadow-purple-950/60 flex items-center justify-center">
              <img
                src="/pwa-192x192.png"
                alt="AI कमाई"
                className="w-full h-full object-cover rounded-2xl"
                onError={(e) => {
                  (e.target as HTMLElement).style.display = 'none';
                }}
              />
              <div className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-emerald-500 border-2 border-zinc-900 flex items-center justify-center">
                <Check className="w-3 h-3 text-white stroke-[3]" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h3 className="font-extrabold text-base text-white">AI कमाई ऐप</h3>
                <span className="text-[10px] bg-emerald-500/20 text-emerald-300 font-bold px-1.5 py-0.5 rounded-full">
                  PWA तैयार
                </span>
              </div>
              <p className="text-xs text-zinc-400">मोबाइल में डाउनलोड व इंस्टॉल करें</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-full bg-zinc-800 text-zinc-400 hover:text-white hover:bg-zinc-700 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4 space-y-4">
          {/* Main Direct Install Action Banner */}
          {isInstalled ? (
            <div className="p-3.5 rounded-2xl bg-emerald-950/60 border border-emerald-500/50 flex items-center gap-3 text-emerald-200">
              <CheckCircle2 className="w-6 h-6 text-emerald-400 flex-shrink-0" />
              <div>
                <p className="text-xs font-bold">ऐप पहले से इंस्टॉल है!</p>
                <p className="text-[11px] text-emerald-300/80">
                  यह ऐप आपकी डिवाइस पर स्टैंडअलोन मोड में सफलतापूर्वक स्थापित है।
                </p>
              </div>
            </div>
          ) : isInstallable ? (
            <div className="p-4 rounded-2xl bg-gradient-to-r from-[#5f259f] to-[#ec4899] shadow-xl text-center space-y-3">
              <div className="flex items-center justify-center gap-2">
                <Sparkles className="w-5 h-5 text-amber-300 animate-spin" />
                <span className="font-extrabold text-sm tracking-wide">1-क्लिक सीधा इंस्टॉल उपलब्ध!</span>
              </div>
              <p className="text-xs text-purple-100 font-medium">
                सीधे अपने मोबाइल की होम स्क्रीन पर ऐप आइकॉन के रूप में डाउनलोड करें।
              </p>
              <button
                type="button"
                id="btn-pwa-install-native"
                onClick={handleNativeInstall}
                disabled={isInstalling}
                className="w-full py-3 px-4 rounded-xl bg-white text-[#5f259f] font-black text-sm hover:bg-zinc-100 shadow-lg transition active:scale-98 cursor-pointer flex items-center justify-center gap-2"
              >
                <Download className="w-4 h-4" />
                <span>{isInstalling ? "इंस्टॉल हो रहा है..." : "अभी मोबाइल में इंस्टॉल करें (Install App)"}</span>
              </button>
            </div>
          ) : (
            <div className="p-3.5 rounded-2xl bg-purple-950/30 border border-purple-800/40 text-xs text-purple-200 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Smartphone className="w-4 h-4 text-purple-400 flex-shrink-0" />
                <span>ब्राउज़र से सीधे होम स्क्रीन पर इंस्टॉल किया जा सकता है।</span>
              </div>
            </div>
          )}

          {/* Tab Selector for Operating Systems */}
          <div className="flex rounded-xl bg-zinc-950 p-1 border border-zinc-800 text-xs font-semibold">
            <button
              type="button"
              onClick={() => setActiveTab('android')}
              className={`flex-1 py-2 rounded-lg transition text-center cursor-pointer ${
                activeTab === 'android'
                  ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              Android (APK/PWA)
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('ios')}
              className={`flex-1 py-2 rounded-lg transition text-center cursor-pointer ${
                activeTab === 'ios'
                  ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              iPhone / iOS
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('zip')}
              className={`flex-1 py-2 rounded-lg transition text-center cursor-pointer ${
                activeTab === 'zip'
                  ? 'bg-zinc-800 text-white shadow'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              APK Build / ZIP
            </button>
          </div>

          {/* Android Step-by-Step Guide */}
          {activeTab === 'android' && (
            <div className="space-y-3 bg-zinc-950/60 p-4 rounded-2xl border border-zinc-800/80">
              <h4 className="text-xs font-bold text-emerald-400 flex items-center gap-1.5">
                <Smartphone className="w-4 h-4" />
                Android फोन में डाउनलोड करने के 3 आसान कदम:
              </h4>

              <div className="space-y-2.5 text-xs text-zinc-300">
                <div className="flex items-start gap-2.5 p-2 rounded-xl bg-zinc-900 border border-zinc-800">
                  <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 font-bold flex items-center justify-center text-[11px] flex-shrink-0 mt-0.5">
                    1
                  </span>
                  <div>
                    <p className="font-semibold text-white">ऐप लिंक को Chrome में खोलें</p>
                    <p className="text-[11px] text-zinc-400">
                      अगर आप किसी इन-ऐप ब्राउज़र में हैं, तो Chrome या अपने मुख्य ब्राउज़र में खोलें।
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-2.5 p-2 rounded-xl bg-zinc-900 border border-zinc-800">
                  <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 font-bold flex items-center justify-center text-[11px] flex-shrink-0 mt-0.5">
                    2
                  </span>
                  <div>
                    <p className="font-semibold text-white">3 डॉट्स (⋮) मेनू पर टैप करें</p>
                    <p className="text-[11px] text-zinc-400">
                      ऊपर दाईं ओर कोने में <strong className="text-white">तीन बिंदुओं (⋮)</strong> पर क्लिक करें।
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-2.5 p-2 rounded-xl bg-zinc-900 border border-zinc-800">
                  <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 font-bold flex items-center justify-center text-[11px] flex-shrink-0 mt-0.5">
                    3
                  </span>
                  <div>
                    <p className="font-semibold text-emerald-400">
                      'Install App' या 'Add to Home screen' चुनें
                    </p>
                    <p className="text-[11px] text-zinc-400">
                      <strong>'होम स्क्रीन में जोड़ें'</strong> पर क्लिक करते ही <strong>AI कमाई</strong> ऐप आपके मोबाइल में असली ऐप की तरह इंस्टॉल हो जाएगी।
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* iOS / iPhone Guide */}
          {activeTab === 'ios' && (
            <div className="space-y-3 bg-zinc-950/60 p-4 rounded-2xl border border-zinc-800/80">
              <h4 className="text-xs font-bold text-purple-300 flex items-center gap-1.5">
                <Share2 className="w-4 h-4" />
                iPhone / iPad (Safari) में इंस्टॉल करें:
              </h4>

              <div className="space-y-2.5 text-xs text-zinc-300">
                <div className="flex items-start gap-2.5 p-2 rounded-xl bg-zinc-900 border border-zinc-800">
                  <span className="w-5 h-5 rounded-full bg-purple-500/20 text-purple-400 font-bold flex items-center justify-center text-[11px] flex-shrink-0 mt-0.5">
                    1
                  </span>
                  <div>
                    <p className="font-semibold text-white">Safari में Share बटन दबाएं</p>
                    <p className="text-[11px] text-zinc-400">
                      सफारी ब्राउज़र में नीचे दिए गए <strong className="text-white">Share (शेयर [↑])</strong> आइकन पर टैप करें।
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-2.5 p-2 rounded-xl bg-zinc-900 border border-zinc-800">
                  <span className="w-5 h-5 rounded-full bg-purple-500/20 text-purple-400 font-bold flex items-center justify-center text-[11px] flex-shrink-0 mt-0.5">
                    2
                  </span>
                  <div>
                    <p className="font-semibold text-purple-300">
                      'Add to Home Screen' (होम स्क्रीन पर जोड़ें)
                    </p>
                    <p className="text-[11px] text-zinc-400">
                      नीचे स्क्रॉल करके <strong className="text-white">+ Add to Home Screen</strong> पर क्लिक करें।
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-2.5 p-2 rounded-xl bg-zinc-900 border border-zinc-800">
                  <span className="w-5 h-5 rounded-full bg-purple-500/20 text-purple-400 font-bold flex items-center justify-center text-[11px] flex-shrink-0 mt-0.5">
                    3
                  </span>
                  <div>
                    <p className="font-semibold text-white">ऊपर 'Add' पर टैप करें</p>
                    <p className="text-[11px] text-zinc-400">
                      ऐप आपके iPhone की होम स्क्रीन पर सेव हो जाएगी और बिना किसी ब्राउज़र बार के फुल स्क्रीन खुलेगी।
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ZIP & APK Build Guide */}
          {activeTab === 'zip' && (
            <div className="space-y-3 bg-zinc-950/60 p-4 rounded-2xl border border-zinc-800/80 text-xs">
              <h4 className="font-bold text-amber-400 flex items-center gap-1.5">
                <Download className="w-4 h-4" />
                Android APK व ZIP कोड कैसे प्राप्त करें:
              </h4>

              <div className="p-3 rounded-xl bg-purple-950/40 border border-purple-800/40 text-purple-200 space-y-1.5">
                <p className="font-bold text-white text-xs">🚀 1. सीधे फोन में APK की तरह चलाएं (PWA):</p>
                <p className="text-[11px] text-zinc-300 leading-relaxed">
                  इस वेब ऐप को आधुनिक <strong>Progressive Web App (PWA)</strong> के रूप में बनाया गया है। इसे जब आप Chrome में <em>"Install App"</em> या <em>"Add to Home screen"</em> करते हैं, तो Android OS इसे बिना किसी APK फ़ाइल के भी सीधे होम स्क्रीन पर एक असली ऐप आइकॉन के साथ फुलस्क्रीन मोड में इंस्टॉल कर देता है।
                </p>
              </div>

              <div className="p-3 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-300 space-y-2">
                <p className="font-bold text-white text-xs">📦 2. शुद्ध <code>.apk</code> फ़ाइल बनाना:</p>
                <p className="text-[11px] text-zinc-400 leading-relaxed">
                  यदि आपको Google Play Store या सीधे इंस्टॉल करने के लिए <code>.apk</code> फ़ाइल चाहिए:
                </p>
                <ol className="list-decimal pl-4 space-y-1.5 text-[11px] text-zinc-300">
                  <li>
                    AI Studio के ऊपरी कोने में <strong>सेटिंग्स</strong> पर जाकर <strong>'Export to ZIP'</strong> से पूरा कोड डाउनलोड करें।
                  </li>
                  <li>
                    इस कोड को <strong>Android Studio</strong> या <strong>Capacitor</strong> (<code>npx cap add android && npx cap build</code>) या <a href="https://pwabuilder.com" target="_blank" rel="noreferrer" className="text-cyan-400 underline">PWABuilder.com</a> पर ऐप का लिंक डालकर 1-क्लिक में <strong>Signed APK / AAB</strong> बना सकते हैं।
                  </li>
                </ol>
              </div>

              <div className="p-2.5 rounded-xl bg-emerald-950/40 border border-emerald-800/40 text-[11px] text-emerald-300 flex items-center gap-2">
                <Zap className="w-4 h-4 flex-shrink-0 text-emerald-400" />
                <span>
                  PWABuilder पर बस ऐप का लाइव यूआरएल पेस्ट करके आप मुफ्त में <strong>Android APK</strong> डाउनलोड कर सकते हैं!
                </span>
              </div>
            </div>
          )}

          {/* App URL Copy Bar */}
          <div className="p-3 rounded-2xl bg-zinc-950 border border-zinc-800 flex items-center justify-between gap-2">
            <div className="overflow-hidden">
              <p className="text-[10px] text-zinc-500 uppercase font-bold">ऐप लिंक (App URL)</p>
              <p className="text-xs font-mono text-zinc-300 truncate select-all">{currentUrl}</p>
            </div>
            <button
              type="button"
              onClick={handleCopyLink}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition cursor-pointer flex-shrink-0 ${
                copiedLink
                  ? 'bg-emerald-600 text-white'
                  : 'bg-zinc-800 hover:bg-zinc-700 text-zinc-200'
              }`}
            >
              {copiedLink ? (
                <>
                  <Check className="w-3.5 h-3.5" />
                  <span>कॉपी हुआ!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>लिंक कॉपी</span>
                </>
              )}
            </button>
          </div>

          {/* Guarantee Badges */}
          <div className="grid grid-cols-2 gap-2 text-[11px] text-zinc-400 pt-1">
            <div className="p-2 rounded-xl bg-zinc-900/60 border border-zinc-800 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400 flex-shrink-0" />
              <span>100% सुरक्षित और वायरस मुक्त</span>
            </div>
            <div className="p-2 rounded-xl bg-zinc-900/60 border border-zinc-800 flex items-center gap-2">
              <Zap className="w-4 h-4 text-purple-400 flex-shrink-0" />
              <span>फास्ट लोडिंग • ऑफलाइन सपोर्ट</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
