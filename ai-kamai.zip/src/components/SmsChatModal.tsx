import React, { useState, useRef, useEffect } from "react";
import {
  X,
  Send,
  Phone,
  Video,
  Sparkles,
  Bot,
  User,
  ArrowLeft,
  Paperclip,
  Smile,
  ShieldCheck,
} from "lucide-react";
import { ChatConversation, Creator, ChatMessage } from "../types";

interface SmsChatModalProps {
  conversations: ChatConversation[];
  activeConversationId?: string;
  onClose: () => void;
  onCallCreator: (creator: Creator, callType?: "audio" | "video") => void;
}

export const SmsChatModal: React.FC<SmsChatModalProps> = ({
  conversations: initialConversations,
  activeConversationId,
  onClose,
  onCallCreator,
}) => {
  const [conversations, setConversations] = useState<ChatConversation[]>(initialConversations);
  const [selectedChatId, setSelectedChatId] = useState<string>(
    activeConversationId || initialConversations[0]?.id || ""
  );
  const [inputText, setInputText] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  const currentChat =
    conversations.find((c) => c.id === selectedChatId) || conversations[0];

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [currentChat?.messages, isTyping]);

  const quickPrompts = [
    "AI से पहले ₹1000 कैसे कमाएं?",
    "YouTube Script के बेस्ट प्रॉम्प्ट्स दो",
    "₹1 में वीडियो कॉल पर क्या सिखाएंगे?",
    "Upwork पर पहला क्लाइंट कैसे मिलेगा?",
  ];

  const handleSendMessage = async (textToSend?: string) => {
    const messageText = (textToSend || inputText).trim();
    if (!messageText || !currentChat) return;

    const userMessage: ChatMessage = {
      id: "msg_" + Date.now(),
      sender: "user",
      text: messageText,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    };

    // Update state with user message
    const updatedMessages = [...currentChat.messages, userMessage];

    setConversations((prev) =>
      prev.map((c) =>
        c.id === currentChat.id
          ? {
              ...c,
              messages: updatedMessages,
              lastMessage: messageText,
              lastTimestamp: "अभी",
            }
          : c
      )
    );

    setInputText("");
    setIsTyping(true);

    try {
      // Call Gemini Server Endpoint for multi-turn conversational AI
      const response = await fetch("/api/gemini/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: updatedMessages,
          creatorName: currentChat.creator.name,
          creatorRole: currentChat.creator.expertise,
          modelChoice: "gemini-3.5-flash",
        }),
      });

      const data = await response.json();
      const replyText =
        data.reply ||
        data.fallbackReply ||
        `धन्यवाद! AI कमाई में मैं आपको पूरी तरह गाइड करूँगा। अगर तुरंत लाइव स्क्रीन पर स्टेप्स समझने हैं, तो ऊपर दिए गए '📞 ₹1' बटन से मुझसे कॉल करें!`;

      const botMessage: ChatMessage = {
        id: "msg_bot_" + Date.now(),
        sender: "creator",
        text: replyText,
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      };

      setConversations((prev) =>
        prev.map((c) =>
          c.id === currentChat.id
            ? {
                ...c,
                messages: [...c.messages, botMessage],
                lastMessage: replyText.substring(0, 45) + "...",
                lastTimestamp: "अभी",
              }
            : c
        )
      );
    } catch (err) {
      console.warn("Chat error fallback:", err);
      const fallbackMsg: ChatMessage = {
        id: "msg_fallback_" + Date.now(),
        sender: "creator",
        text: `नमस्ते! AI से कमाई करने के लिए आप ChatGPT से स्क्रिप्ट्स लिख सकते हैं या AI थंबनेल बना सकते हैं। आप सिर्फ ₹1 में ऑडियो या वीडियो कॉल भी कर सकते हैं!`,
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      };
      setConversations((prev) =>
        prev.map((c) =>
          c.id === currentChat.id
            ? { ...c, messages: [...c.messages, fallbackMsg] }
            : c
        )
      );
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div
      id="sms-chat-modal"
      className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-0 sm:p-4 text-white"
    >
      <div className="relative w-full max-w-3xl h-full sm:h-[88vh] bg-[#121216] border border-zinc-800 sm:rounded-2xl overflow-hidden flex flex-col md:flex-row shadow-2xl">
        {/* Left Side: Conversation List */}
        <div className="w-full md:w-72 bg-[#0e0e11] border-r border-zinc-800 flex flex-col">
          {/* Header */}
          <div className="p-3.5 border-b border-zinc-800 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-pink-400" />
              <h3 className="font-bold text-sm tracking-tight">एसएमएस व डीएम चैटिंग</h3>
            </div>
            <button
              id="btn-close-chat-mobile"
              onClick={onClose}
              className="p-1.5 rounded-full hover:bg-zinc-800 text-zinc-400 md:hidden"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* List */}
          <div className="flex-1 overflow-y-auto divide-y divide-zinc-800/40">
            {conversations.map((chat) => (
              <button
                key={chat.id}
                id={`chat-item-${chat.id}`}
                onClick={() => setSelectedChatId(chat.id)}
                className={`w-full p-3 flex items-center gap-3 text-left transition-colors cursor-pointer ${
                  chat.id === selectedChatId
                    ? "bg-zinc-800/80 border-l-3 border-pink-500"
                    : "hover:bg-zinc-800/40"
                }`}
              >
                <div className="relative flex-shrink-0">
                  <img
                    src={chat.creator.avatar}
                    alt={chat.creator.name}
                    referrerPolicy="no-referrer"
                    className="w-10 h-10 rounded-full object-cover"
                  />
                  {chat.creator.isOnline && (
                    <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-emerald-500 border border-[#121216] rounded-full" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-xs text-zinc-200 truncate">
                      {chat.creator.name}
                    </span>
                    <span className="text-[10px] text-zinc-500">{chat.lastTimestamp}</span>
                  </div>
                  <p className="text-[11px] text-zinc-400 truncate mt-0.5">
                    {chat.lastMessage}
                  </p>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Right Side: Active Chat Thread */}
        <div className="flex-1 flex flex-col bg-[#121216]">
          {/* Thread Header */}
          <div className="px-4 py-3 bg-[#0e0e11] border-b border-zinc-800 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <img
                src={currentChat.creator.avatar}
                alt={currentChat.creator.name}
                referrerPolicy="no-referrer"
                className="w-9 h-9 rounded-full object-cover border border-zinc-700"
              />
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="font-bold text-sm leading-tight">
                    {currentChat.creator.name}
                  </span>
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                </div>
                <p className="text-[10px] text-emerald-400">
                  {currentChat.creator.isOnline ? "● ऑनलाइन • तुरंत जवाब" : "ऑफलाइन"}
                </p>
              </div>
            </div>

            {/* Quick Action: Call Creator Button ₹1 */}
            <div className="flex items-center gap-2">
              <button
                id="btn-chat-audio-call"
                onClick={() => onCallCreator(currentChat.creator, "audio")}
                className="p-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 hover:text-white transition-colors cursor-pointer"
                title="₹1 ऑडियो कॉल"
              >
                <Phone className="w-4 h-4 text-emerald-400" />
              </button>
              <button
                id="btn-chat-video-call"
                onClick={() => onCallCreator(currentChat.creator, "video")}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-xs shadow-sm transition-all active:scale-95 cursor-pointer"
                title="₹1 वीडियो कॉल"
              >
                <Video className="w-3.5 h-3.5" />
                <span>₹1 कॉल</span>
              </button>
              <button
                id="btn-close-chat-desktop"
                onClick={onClose}
                className="p-1.5 rounded-full hover:bg-zinc-800 text-zinc-400 ml-1 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Quick Prompts Chips */}
          <div className="px-3 py-2 bg-zinc-900/60 border-b border-zinc-800/60 overflow-x-auto no-scrollbar flex items-center gap-1.5">
            <span className="text-[10px] text-zinc-500 uppercase tracking-wider font-bold whitespace-nowrap pl-1">
              सुझाव:
            </span>
            {quickPrompts.map((prompt, idx) => (
              <button
                key={idx}
                type="button"
                id={`chip-prompt-${idx}`}
                onClick={() => handleSendMessage(prompt)}
                className="text-[11px] px-2.5 py-1 rounded-full bg-zinc-800 hover:bg-zinc-700 text-zinc-300 hover:text-white border border-zinc-700/60 whitespace-nowrap transition-colors cursor-pointer"
              >
                {prompt}
              </button>
            ))}
          </div>

          {/* Messages Scroll Area */}
          <div
            id="chat-messages-container"
            className="flex-1 p-4 overflow-y-auto space-y-3"
          >
            {/* Call announcement notice */}
            <div className="mx-auto max-w-xs p-2.5 rounded-xl bg-emerald-950/40 border border-emerald-500/30 text-center">
              <p className="text-[11px] text-emerald-300 font-medium">
                💡 क्या आप जानते हैं? आप ₹1 का टोकन भुगतान करके सीधे ऑडियो या वीडियो कॉल पर लाइव टिप्स ले सकते हैं!
              </p>
            </div>

            {currentChat.messages.map((msg) => {
              const isMe = msg.sender === "user";
              return (
                <div
                  key={msg.id}
                  className={`flex items-end gap-2 ${
                    isMe ? "justify-end" : "justify-start"
                  }`}
                >
                  {!isMe && (
                    <img
                      src={currentChat.creator.avatar}
                      alt={currentChat.creator.name}
                      referrerPolicy="no-referrer"
                      className="w-6 h-6 rounded-full object-cover mb-0.5"
                    />
                  )}
                  <div
                    className={`max-w-[75%] rounded-2xl px-3.5 py-2.5 text-xs leading-relaxed shadow-sm ${
                      isMe
                        ? "bg-gradient-to-tr from-pink-600 to-rose-600 text-white rounded-br-xs"
                        : "bg-zinc-800 text-zinc-100 border border-zinc-700/70 rounded-bl-xs"
                    }`}
                  >
                    <p className="whitespace-pre-wrap">{msg.text}</p>
                    <span
                      className={`block text-[9px] mt-1 text-right ${
                        isMe ? "text-pink-200" : "text-zinc-500"
                      }`}
                    >
                      {msg.timestamp}
                    </span>
                  </div>
                </div>
              );
            })}

            {isTyping && (
              <div className="flex items-center gap-2 text-zinc-400 text-xs">
                <img
                  src={currentChat.creator.avatar}
                  alt={currentChat.creator.name}
                  referrerPolicy="no-referrer"
                  className="w-6 h-6 rounded-full object-cover"
                />
                <div className="bg-zinc-800 px-3 py-2 rounded-2xl flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 bg-pink-400 rounded-full animate-bounce" />
                  <span className="w-1.5 h-1.5 bg-pink-400 rounded-full animate-bounce [animation-delay:0.2s]" />
                  <span className="w-1.5 h-1.5 bg-pink-400 rounded-full animate-bounce [animation-delay:0.4s]" />
                  <span className="text-[11px] text-zinc-400 ml-1">टाइप कर रहे हैं...</span>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Input Bar */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="p-3 bg-[#0e0e11] border-t border-zinc-800 flex items-center gap-2"
          >
            <input
              type="text"
              id="input-sms-chat"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="मैसेज लिखें... (उदा: AI स्क्रिप्ट्स कैसे बेचें?)"
              className="flex-1 bg-zinc-900 border border-zinc-700 rounded-full px-4 py-2.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-pink-500"
            />
            <button
              type="submit"
              id="btn-send-sms"
              disabled={!inputText.trim() || isTyping}
              className="p-2.5 rounded-full bg-gradient-to-tr from-pink-600 to-rose-600 hover:from-pink-500 hover:to-rose-500 text-white disabled:opacity-40 transition-all active:scale-95 cursor-pointer shadow-md shadow-pink-900/40"
              title="मैसेज भेजें"
            >
              <Send className="w-4 h-4 -rotate-12" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
