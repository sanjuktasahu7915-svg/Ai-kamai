import React, { useState } from 'react';
import { Download, Sparkles } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { InstallAppModal } from './InstallAppModal';

export const PWAInstallButton: React.FC = () => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showModal, setShowModal] = useState(false);

  // If already installed, don't show the prominent install badge
  if (isInstalled) {
    return (
      <>
        <button
          type="button"
          onClick={() => setShowModal(true)}
          title="ऐप इंस्टॉल्ड जानकारी"
          className="flex items-center gap-1 text-[11px] font-bold px-2 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30"
        >
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
          <span>इंस्टॉल्ड</span>
        </button>
        <InstallAppModal isOpen={showModal} onClose={() => setShowModal(false)} />
      </>
    );
  }

  const handleClick = async () => {
    if (isInstallable) {
      try {
        const accepted = await install();
        if (!accepted) {
          setShowModal(true);
        }
      } catch {
        setShowModal(true);
      }
    } else {
      setShowModal(true);
    }
  };

  return (
    <>
      <button
        type="button"
        id="btn-download-install-app"
        onClick={handleClick}
        className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-gradient-to-r from-purple-600 via-pink-600 to-rose-600 hover:from-purple-500 hover:to-rose-500 text-white font-extrabold text-xs shadow-md shadow-pink-950/40 active:scale-95 transition-all cursor-pointer border border-pink-400/30 animate-pulse"
      >
        <Download className="w-3.5 h-3.5" />
        <span>ऐप डाउनलोड करें</span>
      </button>

      <InstallAppModal isOpen={showModal} onClose={() => setShowModal(false)} />
    </>
  );
};
