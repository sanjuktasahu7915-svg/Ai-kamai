import React, { useState } from "react";
import { Copy, Check, Share2, Download, ExternalLink, ShieldCheck } from "lucide-react";

interface PhonePeQrCardProps {
  amount?: number;
  note?: string;
  showPayLink?: boolean;
}

export const PhonePeQrCard: React.FC<PhonePeQrCardProps> = ({
  amount = 1,
  note = "AI Call Fee",
  showPayLink = true,
}) => {
  const [copied, setCopied] = useState(false);
  const [sharedToast, setSharedToast] = useState(false);

  const upiId = "9668474743-4@ybl";
  const bankName = "State Bank of India - 2788";
  const payeeName = "AI Kamai Creator";

  // Standard UPI deep-link URI
  const upiUri = `upi://pay?pa=${encodeURIComponent(upiId)}&pn=${encodeURIComponent(
    payeeName
  )}&am=${amount.toFixed(2)}&cu=INR&tn=${encodeURIComponent(note)}`;

  // Quick reliable QR generator URL
  const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&margin=10&data=${encodeURIComponent(
    upiUri
  )}`;

  const handleCopyUpi = async () => {
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(upiId);
      } else {
        const textarea = document.createElement("textarea");
        textarea.value = upiId;
        textarea.style.position = "fixed";
        textarea.style.opacity = "0";
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand("copy");
        document.body.removeChild(textarea);
      }
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator
        .share({
          title: "PhonePe UPI - AI कमाई",
          text: `PhonePe UPI ID: ${upiId} (${bankName}) पर ₹${amount} पे करें।`,
          url: window.location.href,
        })
        .catch(() => {});
    } else {
      setSharedToast(true);
      setTimeout(() => setSharedToast(false), 2500);
    }
  };

  return (
    <div className="w-full bg-white text-zinc-900 rounded-3xl overflow-hidden shadow-xl border border-zinc-200">
      {/* PhonePe Top Brand Bar */}
      <div className="bg-[#5f259f] text-white px-4 py-2.5 flex items-center justify-between">
        <div className="flex items-center gap-2">
          {/* PhonePe 'पे' Iconic Badge */}
          <div className="w-6 h-6 rounded-full bg-white text-[#5f259f] font-black text-xs flex items-center justify-center shadow">
            पे
          </div>
          <span className="font-bold text-sm tracking-wide">PhonePe QR</span>
        </div>
        <div className="flex items-center gap-1.5 text-[11px] font-semibold bg-white/15 px-2.5 py-0.5 rounded-full">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-300" />
          <span>वेरिफाइड मर्चेंट</span>
        </div>
      </div>

      {/* Account Info matching PhonePe Screenshot */}
      <div className="p-4 bg-zinc-50 border-b border-zinc-100 flex items-center justify-between">
        <div className="flex items-center gap-3">
          {/* SBI Circle Logo */}
          <div className="w-10 h-10 rounded-full bg-[#0082c6] text-white font-black text-xs flex items-center justify-center shadow-sm">
            SBI
          </div>
          <div>
            <h4 className="font-bold text-sm text-zinc-900 leading-tight">
              {bankName}
            </h4>
            <p className="text-[11px] text-zinc-500 font-medium">
              Primary account for receiving money
            </p>
          </div>
        </div>

        {/* Action icons like screenshot */}
        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={handleShare}
            title="शेयर करें"
            className="p-2 rounded-xl text-zinc-600 hover:bg-zinc-200 transition-colors"
          >
            <Share2 className="w-4 h-4" />
          </button>
          <a
            href={qrCodeUrl}
            download="PhonePe_QR_9668474743-4.png"
            target="_blank"
            rel="noreferrer"
            title="डाउनलोड करें"
            className="p-2 rounded-xl text-zinc-600 hover:bg-zinc-200 transition-colors"
          >
            <Download className="w-4 h-4" />
          </a>
        </div>
      </div>

      {/* Main QR Display */}
      <div className="p-5 flex flex-col items-center justify-center bg-white">
        <div className="relative p-2.5 bg-white rounded-2xl border-2 border-zinc-200 shadow-inner flex items-center justify-center">
          <img
            src={qrCodeUrl}
            alt={`PhonePe QR for ${upiId}`}
            className="w-48 h-48 object-contain rounded-lg"
          />
          {/* Centered PhonePe Logo inside QR */}
          <div className="absolute inset-0 m-auto w-10 h-10 rounded-full bg-white p-0.5 shadow-md flex items-center justify-center">
            <div className="w-full h-full rounded-full bg-[#5f259f] text-white flex items-center justify-center font-bold text-sm">
              पे
            </div>
          </div>
        </div>

        {/* Amount Pill */}
        <div className="mt-3 px-3 py-1 bg-purple-50 border border-purple-200 rounded-full text-xs font-bold text-[#5f259f] flex items-center gap-1.5">
          <span>देय राशि (Payable):</span>
          <span className="text-sm font-black text-emerald-600">₹{amount.toFixed(2)}</span>
        </div>

        {/* UPI ID Row with Copy */}
        <div className="mt-3.5 w-full bg-zinc-100 rounded-xl p-2.5 flex items-center justify-between border border-zinc-200">
          <div className="text-left overflow-hidden mr-2">
            <p className="text-[10px] text-zinc-500 font-semibold uppercase tracking-wider">
              PhonePe UPI ID
            </p>
            <p className="font-mono text-xs font-bold text-zinc-900 truncate select-all">
              {upiId}
            </p>
          </div>
          <button
            type="button"
            onClick={handleCopyUpi}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
              copied
                ? "bg-emerald-600 text-white shadow"
                : "bg-[#5f259f] hover:bg-[#4d1d82] text-white shadow-sm"
            }`}
          >
            {copied ? (
              <>
                <Check className="w-3.5 h-3.5" />
                <span>कॉपी हुआ!</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" />
                <span>कॉपी करें</span>
              </>
            )}
          </button>
        </div>

        {/* Direct Deep Link Button for Mobile UPI Apps */}
        {showPayLink && (
          <a
            href={upiUri}
            className="mt-3 w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-[#5f259f] to-[#7b2cbf] hover:from-[#521f8a] hover:to-[#6a25a6] text-white text-xs font-bold flex items-center justify-center gap-2 shadow-md transition-all active:scale-98"
          >
            <span>PhonePe ऐप में ₹{amount} खोलें</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        )}

        {sharedToast && (
          <p className="text-[11px] text-emerald-600 font-semibold mt-2">
            UPI ID: {upiId} क्लिपबोर्ड पर कॉपी कर दी गई है!
          </p>
        )}
      </div>

      {/* Footer Banner matching PhonePe screenshot */}
      <div className="bg-zinc-100 px-4 py-2 border-t border-zinc-200 text-center">
        <p className="text-[10px] text-zinc-600 font-medium leading-tight">
          सभी UPI ऐप्स से स्वीकार्य: <span className="font-bold text-zinc-800">PhonePe • BHIM • Google Pay • Paytm</span>
        </p>
        <p className="text-[9px] text-zinc-400 font-bold uppercase tracking-wider mt-0.5">
          Powered by UPI
        </p>
      </div>
    </div>
  );
};
