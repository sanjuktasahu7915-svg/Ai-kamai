import React from "react";
import { Home, Compass, PlusSquare, Wallet, Send } from "lucide-react";

interface BottomNavProps {
  currentTab: "home" | "explore" | "wallet" | "chat";
  unreadMessagesCount: number;
  walletBalance: number;
  onSelectTab: (tab: "home" | "explore" | "wallet" | "chat") => void;
  onOpenCreate: () => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  currentTab,
  unreadMessagesCount,
  walletBalance,
  onSelectTab,
  onOpenCreate,
}) => {
  return (
    <nav
      id="bottom-navigation-bar"
      className="fixed bottom-0 inset-x-0 z-40 bg-[#0e0e11]/95 backdrop-blur-md border-t border-zinc-800/80 px-2 py-1.5 text-white"
    >
      <div className="max-w-lg mx-auto flex items-center justify-around">
        {/* Home */}
        <button
          type="button"
          id="nav-btn-home"
          onClick={() => onSelectTab("home")}
          className={`flex flex-col items-center gap-0.5 py-1 px-3 rounded-xl transition-all cursor-pointer ${
            currentTab === "home" ? "text-pink-500 scale-105" : "text-zinc-400 hover:text-zinc-200"
          }`}
        >
          <Home className="w-5 h-5" />
          <span className="text-[10px] font-medium">होम</span>
        </button>

        {/* Explore Creators / Call Hub */}
        <button
          type="button"
          id="nav-btn-explore"
          onClick={() => onSelectTab("explore")}
          className={`flex flex-col items-center gap-0.5 py-1 px-3 rounded-xl transition-all cursor-pointer ${
            currentTab === "explore" ? "text-pink-500 scale-105" : "text-zinc-400 hover:text-zinc-200"
          }`}
        >
          <Compass className="w-5 h-5" />
          <span className="text-[10px] font-medium">₹1 कॉल्स</span>
        </button>

        {/* Plus / Create */}
        <button
          type="button"
          id="nav-btn-create"
          onClick={onOpenCreate}
          className="flex flex-col items-center justify-center -mt-3.5 group cursor-pointer"
          title="नई AI पोस्ट या इमेज बनाएं"
        >
          <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-pink-600 via-rose-500 to-amber-500 flex items-center justify-center text-white shadow-lg shadow-pink-900/50 group-hover:scale-105 group-active:scale-95 transition-all">
            <PlusSquare className="w-6 h-6 stroke-[2.2]" />
          </div>
          <span className="text-[9px] font-bold text-pink-400 mt-0.5">बनाएं</span>
        </button>

        {/* Wallet / Payments */}
        <button
          type="button"
          id="nav-btn-wallet"
          onClick={() => onSelectTab("wallet")}
          className={`flex flex-col items-center gap-0.5 py-1 px-3 rounded-xl transition-all cursor-pointer ${
            currentTab === "wallet" ? "text-emerald-400 scale-105" : "text-zinc-400 hover:text-zinc-200"
          }`}
        >
          <div className="relative">
            <Wallet className="w-5 h-5" />
          </div>
          <span className="text-[10px] font-medium">वॉलेट (₹{walletBalance})</span>
        </button>

        {/* SMS Chatting */}
        <button
          type="button"
          id="nav-btn-chat"
          onClick={() => onSelectTab("chat")}
          className={`relative flex flex-col items-center gap-0.5 py-1 px-3 rounded-xl transition-all cursor-pointer ${
            currentTab === "chat" ? "text-pink-500 scale-105" : "text-zinc-400 hover:text-zinc-200"
          }`}
        >
          <div className="relative">
            <Send className="w-5 h-5 -rotate-12" />
            {unreadMessagesCount > 0 && (
              <span className="absolute -top-1 -right-2 w-3.5 h-3.5 bg-pink-600 text-[9px] font-bold text-white rounded-full flex items-center justify-center">
                {unreadMessagesCount}
              </span>
            )}
          </div>
          <span className="text-[10px] font-medium">SMS चैट</span>
        </button>
      </div>
    </nav>
  );
};
