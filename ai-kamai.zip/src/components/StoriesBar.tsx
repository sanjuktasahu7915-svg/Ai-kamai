import React from "react";
import { Plus } from "lucide-react";
import { Story } from "../types";

interface StoriesBarProps {
  stories: Story[];
  onSelectStory: (story: Story) => void;
  onAddStory: () => void;
}

export const StoriesBar: React.FC<StoriesBarProps> = ({
  stories,
  onSelectStory,
  onAddStory,
}) => {
  return (
    <div
      id="stories-container"
      className="bg-[#0e0e11] border-b border-zinc-800/60 py-3.5 px-3 overflow-x-auto no-scrollbar"
    >
      <div className="max-w-2xl mx-auto flex items-center gap-3.5">
        {/* User's own story item */}
        <button
          id="btn-user-story"
          onClick={onAddStory}
          className="flex flex-col items-center gap-1.5 flex-shrink-0 group cursor-pointer focus:outline-none"
        >
          <div className="relative">
            <div className="w-[66px] h-[66px] rounded-full p-[2px] bg-zinc-700/80 group-hover:bg-zinc-600 transition-colors">
              <img
                src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&auto=format&fit=crop&q=80"
                alt="आपकी स्टोरी"
                referrerPolicy="no-referrer"
                className="w-full h-full rounded-full object-cover grayscale-[30%] group-hover:grayscale-0 transition-all"
              />
            </div>
            <div className="absolute bottom-0 right-0 w-5 h-5 bg-pink-600 rounded-full border-2 border-[#0e0e11] flex items-center justify-center text-white shadow-sm">
              <Plus className="w-3.5 h-3.5 stroke-[3]" />
            </div>
          </div>
          <span className="text-xs text-zinc-300 font-medium tracking-tight">
            आपकी
          </span>
        </button>

        {/* Creator Stories */}
        {stories.map((story) => (
          <button
            key={story.id}
            id={`story-btn-${story.creatorName}`}
            onClick={() => onSelectStory(story)}
            className="flex flex-col items-center gap-1.5 flex-shrink-0 group cursor-pointer focus:outline-none"
          >
            <div className="relative p-[2.5px] rounded-full bg-gradient-to-tr from-amber-500 via-rose-500 to-fuchsia-600 group-hover:scale-105 transition-transform duration-200 shadow-sm shadow-rose-950/40">
              <div className="w-[62px] h-[62px] rounded-full p-[2px] bg-[#0e0e11]">
                <img
                  src={story.creatorAvatar}
                  alt={story.creatorName}
                  referrerPolicy="no-referrer"
                  className="w-full h-full rounded-full object-cover"
                />
              </div>
            </div>
            <span className="text-xs text-zinc-200 font-medium tracking-tight truncate max-w-[68px]">
              {story.creatorName}
            </span>
          </button>
        ))}
      </div>
    </div>
  );
};
