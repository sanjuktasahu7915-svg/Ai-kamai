import React, { useState } from "react";
import {
  X,
  Phone,
  Video,
  ShieldCheck,
  CheckCircle2,
  Wallet,
  QrCode,
  Sparkles,
  ArrowRight,
  Lock,
  Copy,
  Check,
  ExternalLink,
} from "lucide-react";
import confetti from "canvas-confetti";
import { Creator } from "../types";
import { PhonePeQrCard } from "./PhonePeQrCard";

interface UnlockCallModalProps {
  creator: Creator;
  walletBalance: number;
  initialCallType?: "audio" | "video";
  onClose: () => void;
  onPaymentSuccess: (
    creator: Creator,
    callType: "audio" | "video",
    paymentMethod: "Wallet" | "UPI" | "GPay" | "PhonePe" | "Paytm" | "Card"
  ) => void;
}

export const UnlockCallModal: React.FC<UnlockCallModalProps> = ({
  creator,
  walletBalance,
  initialCallType = "video",
  onClose,
  onPaymentSuccess,
}) => {
  const [callType, setCallType] = useState<"audio" | "video">(initialCallType);
  // Default to PhonePe as primary requested payment method
  const [paymentMethod, setPaymentMethod] = useState<
    "Wallet" | "UPI" | "GPay" | "PhonePe" | "Paytm" | "Card"
  >("PhonePe");
  const phonepeUpiId = "9668474743-4@ybl";
  const [copiedUpi, setCopiedUpi] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [showQrDetails, setShowQrDetails] = useState(true);

  const handleCopyPhonePeId = async () => {
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(phonepeUpiId);
      } else {
        const textarea = document.createElement("textarea");
        textarea.value = phonepeUpiId;
        textarea.style.position = "fixed";
        textarea.style.opacity = "0";
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand("copy");
        document.body.removeChild(textarea);
      }
      setCopiedUpi(true);
      setTimeout(() => setCopiedUpi(false), 2000);
    } catch {
      setCopiedUpi(true);
      setTimeout(() => setCopiedUpi(false), 2000);
    }
  };

  const handlePayAndCall = async () => {
    setIsProcessing(true);

    try {
      // Server-side payment call with exact PhonePe details
      await fetch("/api/payments/process-call-fee", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          creatorId: creator.id,
          callType,
          paymentMethod,
          upiId: phonepeUpiId,
          bankAccount: "State Bank of India - 2788",
          amount: 1,
        }),
      });
    } catch (e) {
      console.warn("Payment API log fallback:", e);
    }

    // Realistic brief gateway delay for authenticity
    setTimeout(() => {
      setIsProcessing(false);
      setIsSuccess(true);

      // Fire celebratory confetti
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
          colors: ["#5f259f", "#10b981", "#ec4899", "#f59e0b"],
        });
      } catch (err) {
        // ignore if not loaded
      }

      // Transition to call after brief celebration
      setTimeout(() => {
        onPaymentSuccess(creator, callType, paymentMethod);
      }, 1200);
    }, 900);
  };

  return (
    <div
      id="unlock-call-modal"
      className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4 text-white animate-in fade-in duration-200"
    >
      <div className="relative w-full max-w-md bg-zinc-900 border border-zinc-800 rounded-3xl overflow-hidden shadow-2xl">
        {/* Header Ribbon */}
        <div className="bg-gradient-to-r from-emerald-600 via-teal-600 to-green-600 px-5 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-full bg-black/20">
              <Sparkles className="w-4 h-4 text-emerald-200" />
            </div>
            <div>
              <h3 className="font-bold text-base leading-tight">₹1 कॉल अनलॉक गेटवे</h3>
              <p className="text-[11px] text-emerald-100 font-medium">
                1-on-1 लाइव गाइडेंस & AI कमाई मेंटरशिप
              </p>
            </div>
          </div>
          <button
            id="btn-close-payment-modal"
            onClick={onClose}
            disabled={isProcessing}
            className="p-1.5 rounded-full bg-black/20 hover:bg-black/40 text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4">
          {/* Creator Profile Summary */}
          <div className="flex items-center gap-3.5 p-3 rounded-2xl bg-zinc-800/60 border border-zinc-700/60">
            <div className="relative">
              <img
                src={creator.avatar}
                alt={creator.name}
                referrerPolicy="no-referrer"
                className="w-13 h-13 rounded-full object-cover border-2 border-emerald-500/80 shadow-md"
              />
              <span className="absolute bottom-0 right-0 w-3.5 h-3.5 bg-emerald-500 border-2 border-zinc-900 rounded-full" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-1.5">
                <h4 className="font-bold text-sm text-white truncate">{creator.name}</h4>
                <ShieldCheck className="w-4 h-4 text-emerald-400 flex-shrink-0" />
              </div>
              <p className="text-xs text-zinc-400 truncate">@{creator.handle}</p>
              <p className="text-[11px] text-emerald-400 font-medium mt-0.5">
                {creator.expertise} • {creator.totalCallsCompleted}+ कॉल पूरे किए
              </p>
            </div>
            <div className="text-right flex-shrink-0">
              <span className="text-2xl font-black text-emerald-400">₹1</span>
              <p className="text-[10px] text-zinc-400 font-medium">प्रति सेशन</p>
            </div>
          </div>

          {/* Call Type Selection: Audio or Video */}
          <div>
            <label className="text-xs font-semibold text-zinc-300 block mb-2">
              1. कॉल का प्रकार चुनें (Call Type):
            </label>
            <div className="grid grid-cols-2 gap-2.5">
              {/* Video Call Option */}
              <button
                type="button"
                id="select-video-call"
                onClick={() => setCallType("video")}
                className={`p-3 rounded-2xl border text-left transition-all cursor-pointer relative ${
                  callType === "video"
                    ? "bg-emerald-950/70 border-emerald-500 text-white ring-1 ring-emerald-500 shadow-lg shadow-emerald-950/40"
                    : "bg-zinc-800/50 border-zinc-700/60 text-zinc-400 hover:bg-zinc-800"
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <Video
                    className={`w-5 h-5 ${
                      callType === "video" ? "text-emerald-400" : "text-zinc-400"
                    }`}
                  />
                  <span className="text-xs font-bold px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300">
                    ₹1
                  </span>
                </div>
                <p className="text-xs font-bold text-zinc-100">वीडियो कॉल (Video Call)</p>
                <p className="text-[10px] text-zinc-400 mt-0.5">लाइव फेस-टू-फेस एचडी स्क्रीन</p>
              </button>

              {/* Audio Call Option */}
              <button
                type="button"
                id="select-audio-call"
                onClick={() => setCallType("audio")}
                className={`p-3 rounded-2xl border text-left transition-all cursor-pointer relative ${
                  callType === "audio"
                    ? "bg-emerald-950/70 border-emerald-500 text-white ring-1 ring-emerald-500 shadow-lg shadow-emerald-950/40"
                    : "bg-zinc-800/50 border-zinc-700/60 text-zinc-400 hover:bg-zinc-800"
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <Phone
                    className={`w-5 h-5 ${
                      callType === "audio" ? "text-emerald-400" : "text-zinc-400"
                    }`}
                  />
                  <span className="text-xs font-bold px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300">
                    ₹1
                  </span>
                </div>
                <p className="text-xs font-bold text-zinc-100">ऑडियो कॉल (Audio Call)</p>
                <p className="text-[10px] text-zinc-400 mt-0.5">क्लियर एचडी वॉइस चैट</p>
              </button>
            </div>
          </div>

          {/* Payment Method Selection */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-zinc-300">
                2. पेमेंट मेथड चुनें (Payment Method):
              </label>
              <span className="text-[11px] text-zinc-400 flex items-center gap-1">
                <Lock className="w-3 h-3 text-emerald-400" /> 100% सुरक्षित भुगतान
              </span>
            </div>

            <div className="space-y-2.5">
              {/* Option 1: PhonePe (Primary Requested Method) */}
              <div
                className={`rounded-2xl border transition-all overflow-hidden ${
                  paymentMethod === "PhonePe"
                    ? "bg-zinc-900 border-[#5f259f] ring-1 ring-[#5f259f] shadow-lg shadow-purple-950/40"
                    : "bg-zinc-800/40 border-zinc-700/60 hover:bg-zinc-800/70"
                }`}
              >
                <button
                  type="button"
                  id="pm-phonepe"
                  onClick={() => setPaymentMethod("PhonePe")}
                  className="w-full p-3 flex items-center justify-between text-left cursor-pointer"
                >
                  <div className="flex items-center gap-2.5">
                    {/* PhonePe Iconic Logo badge */}
                    <div className="w-8 h-8 rounded-xl bg-[#5f259f] flex items-center justify-center text-white font-black text-sm shadow-md">
                      पे
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <p className="text-xs font-bold text-white leading-tight">
                          PhonePe (SBI - 2788)
                        </p>
                        <span className="text-[9px] bg-purple-500/20 text-purple-300 font-bold px-1.5 py-0.2 rounded-full">
                          सुझाया गया
                        </span>
                      </div>
                      <p className="text-[11px] text-zinc-300 font-mono mt-0.5">
                        {phonepeUpiId}
                      </p>
                      <p className="text-[10px] text-zinc-400">
                        State Bank of India • प्राथमिक खाता
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {paymentMethod === "PhonePe" && (
                      <CheckCircle2 className="w-5 h-5 text-[#9d4edd]" />
                    )}
                  </div>
                </button>

                {/* Expanded PhonePe QR & Details */}
                {paymentMethod === "PhonePe" && (
                  <div className="px-3 pb-3 pt-1 border-t border-zinc-800/80">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-[11px] font-semibold text-purple-300">
                        PhonePe QR कोड व UPI ID:
                      </span>
                      <button
                        type="button"
                        onClick={() => setShowQrDetails(!showQrDetails)}
                        className="text-[10px] text-zinc-400 hover:text-white underline cursor-pointer"
                      >
                        {showQrDetails ? "QR छुपाएं" : "QR दिखाएं"}
                      </button>
                    </div>

                    {showQrDetails && (
                      <div className="animate-in fade-in zoom-in-95 duration-200">
                        <PhonePeQrCard
                          amount={1}
                          note={`${callType === "video" ? "वीडियो कॉल" : "ऑडियो कॉल"} - ${creator.handle}`}
                          showPayLink={true}
                        />
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Option 2: AI कमाई Wallet */}
              <button
                type="button"
                id="pm-wallet"
                onClick={() => setPaymentMethod("Wallet")}
                className={`w-full p-3 rounded-2xl border flex items-center justify-between text-left transition-all cursor-pointer ${
                  paymentMethod === "Wallet"
                    ? "bg-zinc-800 border-emerald-500 text-white ring-1 ring-emerald-500/60"
                    : "bg-zinc-800/40 border-zinc-700/60 text-zinc-300 hover:bg-zinc-800/70"
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-xl bg-emerald-500/20 flex items-center justify-center text-emerald-400">
                    <Wallet className="w-4 h-4" />
                  </div>
                  <div>
                    <p className="text-xs font-bold leading-tight">AI कमाई वॉलेट</p>
                    <p className="text-[10px] text-zinc-400">
                      उपलब्ध बैलेंस:{" "}
                      <span className="text-emerald-400 font-semibold">₹{walletBalance}</span>
                    </p>
                  </div>
                </div>
                {paymentMethod === "Wallet" && (
                  <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                )}
              </button>

              {/* Option 3: Other UPI Apps (GPay, Paytm, BHIM) */}
              <button
                type="button"
                id="pm-upi"
                onClick={() => setPaymentMethod("UPI")}
                className={`w-full p-2.5 rounded-2xl border flex items-center justify-between text-left transition-all cursor-pointer ${
                  paymentMethod === "UPI"
                    ? "bg-zinc-800 border-indigo-500 text-white ring-1 ring-indigo-500/60"
                    : "bg-zinc-800/40 border-zinc-700/60 text-zinc-300 hover:bg-zinc-800/70"
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-xl bg-indigo-500/20 flex items-center justify-center text-indigo-400 font-bold text-xs">
                    UPI
                  </div>
                  <div>
                    <p className="text-xs font-bold leading-tight">अन्य UPI (Google Pay, Paytm)</p>
                    <p className="text-[10px] text-zinc-400">
                      ID: <span className="text-zinc-200 font-mono">{phonepeUpiId}</span>
                    </p>
                  </div>
                </div>
                {paymentMethod === "UPI" && (
                  <CheckCircle2 className="w-4 h-4 text-indigo-400" />
                )}
              </button>
            </div>
          </div>

          {/* Amount Breakdown Summary */}
          <div className="p-3 rounded-2xl bg-zinc-950/70 border border-zinc-800/80 flex items-center justify-between text-xs">
            <div>
              <span className="text-zinc-400 block text-[11px]">कुल देय राशि (Payable):</span>
              <span className="text-[10px] text-zinc-500">
                प्राप्तकर्ता: PhonePe ({phonepeUpiId})
              </span>
            </div>
            <span className="font-black text-emerald-400 text-base">₹1.00</span>
          </div>

          {/* Success Confirmation Animation */}
          {isSuccess && (
            <div className="p-3.5 rounded-2xl bg-emerald-950/90 border border-emerald-500/80 text-center animate-in zoom-in-95">
              <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto mb-1 animate-bounce" />
              <p className="text-sm font-bold text-emerald-200">₹1 भुगतान सफल!</p>
              <p className="text-xs text-emerald-300 font-medium">
                PhonePe (SBI - 2788 • {phonepeUpiId}) पर प्राप्त हुआ
              </p>
              <p className="text-[11px] text-emerald-400/80 mt-1">
                {callType === "video" ? "वीडियो कॉल" : "ऑडियो कॉल"} से जोड़ा जा रहा है...
              </p>
            </div>
          )}

          {/* Submit Pay & Call Button */}
          {!isSuccess && (
            <button
              type="button"
              id="btn-confirm-pay-1rs"
              onClick={handlePayAndCall}
              disabled={isProcessing}
              className={`w-full py-3.5 px-4 rounded-2xl text-white font-bold text-sm flex items-center justify-center gap-2 shadow-lg active:scale-98 transition-all disabled:opacity-50 cursor-pointer ${
                paymentMethod === "PhonePe"
                  ? "bg-gradient-to-r from-[#5f259f] via-[#7b2cbf] to-[#5f259f] hover:from-[#521f8a] hover:to-[#6a25a6] shadow-purple-950/50"
                  : "bg-gradient-to-r from-emerald-500 via-green-500 to-emerald-600 hover:from-emerald-400 hover:to-green-400 shadow-emerald-900/50"
              }`}
            >
              {isProcessing ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  <span>पेमेंट प्रोसेस हो रहा है...</span>
                </>
              ) : (
                <>
                  <span>
                    {paymentMethod === "PhonePe"
                      ? `₹1 PhonePe से पे करें & कॉल शुरू करें`
                      : paymentMethod === "Wallet"
                      ? `वॉलेट से ₹1 पे करें & कॉल शुरू करें`
                      : `₹1 पे करें और ${callType === "video" ? "वीडियो कॉल" : "ऑडियो कॉल"} शुरू करें`}
                  </span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          )}

          <p className="text-[10px] text-zinc-500 text-center">
            ₹1 का भुगतान 100% सुरक्षित है। कॉल समाप्त होने पर क्रिएटर को SBI - 2788 खाते में क्रेडिट होगा।
          </p>
        </div>
      </div>
    </div>
  );
};
