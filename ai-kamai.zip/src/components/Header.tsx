import React from "react";
import { Sparkles, Send, Wallet, PlusSquare } from "lucide-react";
import { PWAInstallButton } from "./PWAInstallButton";

interface HeaderProps {
  walletBalance: number;
  unreadCount: number;
  onOpenWallet: () => void;
  onOpenChat: () => void;
  onOpenCreate: () => void;
  onHomeClick: () => void;
  onOpenInstall?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  walletBalance,
  unreadCount,
  onOpenWallet,
  onOpenChat,
  onOpenCreate,
  onHomeClick,
}) => {
  return (
    <header
      id="app-header"
      className="sticky top-0 z-30 bg-[#0e0e11]/95 backdrop-blur-md border-b border-zinc-800/80 px-4 py-3 text-white"
    >
      <div className="max-w-2xl mx-auto flex items-center justify-between">
        {/* App Logo & Title */}
        <button
          id="btn-logo-home"
          onClick={onHomeClick}
          className="flex items-center gap-2.5 group transition-transform active:scale-95 text-left"
        >
          <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-pink-500 via-rose-500 to-amber-400 p-[1.5px] shadow-sm shadow-pink-500/30 flex items-center justify-center">
            <div className="w-full h-full bg-[#121216] rounded-full flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-pink-400 group-hover:rotate-12 transition-transform duration-300" />
            </div>
          </div>
          <div className="flex flex-col">
            <span className="text-xl font-bold tracking-tight bg-gradient-to-r from-white via-zinc-100 to-zinc-300 bg-clip-text text-transparent">
              AI कमाई
            </span>
          </div>
        </button>

        {/* Right Action Icons & Download Button */}
        <div className="flex items-center gap-2 sm:gap-2.5">
          {/* In-App PWA Install / Download Button */}
          <PWAInstallButton />

          {/* Wallet Balance Badge */}
          <button
            id="btn-header-wallet"
            onClick={onOpenWallet}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-full bg-zinc-800/90 hover:bg-zinc-700/90 border border-zinc-700/60 text-xs font-semibold text-emerald-400 transition-all active:scale-95"
            title="वॉलेट और पेमेंट मेथड"
          >
            <Wallet className="w-3.5 h-3.5 text-emerald-400" />
            <span>₹{walletBalance}</span>
          </button>

          {/* Create Post Button */}
          <button
            id="btn-header-create-post"
            onClick={onOpenCreate}
            className="p-2 rounded-full hover:bg-zinc-800 text-zinc-300 hover:text-white transition-colors active:scale-90"
            title="नई AI पोस्ट या इमेज बनाएं"
          >
            <PlusSquare className="w-5 h-5" />
          </button>

          {/* DM / SMS Chatting Button */}
          <button
            id="btn-header-messages"
            onClick={onOpenChat}
            className="relative p-2 rounded-full hover:bg-zinc-800 text-zinc-300 hover:text-white transition-colors active:scale-90"
            title="एसएमएस व डीएम चैटिंग"
          >
            <Send className="w-5 h-5 -rotate-12" />
            {unreadCount > 0 && (
              <span className="absolute top-1 right-1 min-w-[17px] h-[17px] px-1 bg-pink-600 text-[10px] font-bold text-white rounded-full flex items-center justify-center shadow-md shadow-pink-600/50">
                {unreadCount}
              </span>
            )}
          </button>
        </div>
      </div>
    </header>
  );
};
