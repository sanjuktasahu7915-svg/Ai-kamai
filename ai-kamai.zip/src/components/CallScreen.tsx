import React, { useEffect, useRef, useState } from "react";
import {
  PhoneOff,
  Mic,
  MicOff,
  Video as VideoIcon,
  VideoOff,
  Volume2,
  VolumeX,
  Sparkles,
  Maximize2,
  SwitchCamera,
  MessageSquare,
} from "lucide-react";
import { Creator } from "../types";

interface CallScreenProps {
  creator: Creator;
  callType: "audio" | "video";
  onEndCall: () => void;
  onOpenChatWithCreator: (creator: Creator) => void;
}

export const CallScreen: React.FC<CallScreenProps> = ({
  creator,
  callType,
  onEndCall,
  onOpenChatWithCreator,
}) => {
  const [duration, setDuration] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoDisabled, setIsVideoDisabled] = useState(false);
  const [isSpeakerOn, setIsSpeakerOn] = useState(true);
  const [callStatus, setCallStatus] = useState<"connecting" | "connected">("connecting");
  const [activeTopicIndex, setActiveTopicIndex] = useState(0);
  const [isSpeaking, setIsSpeaking] = useState(true);

  const localVideoRef = useRef<HTMLVideoElement | null>(null);
  const localStreamRef = useRef<MediaStream | null>(null);

  // Talking points / advice spoken by the creator during the call
  const creatorAdvice = [
    `नमस्ते! मैं ${creator.name} हूँ। आपका ₹1 का सेशन शुरू हो चुका है!`,
    `AI से पैसे कमाने का पहला सीक्रेट है: यूट्यूबर्स और रील्स क्रिएटर्स को हाई-कन्वर्टिंग 60s स्क्रिप्ट्स डिलीवर करना।`,
    `क्लाइंट्स को फ्रीलांसिंग साइट्स जैसे Upwork और Fiverr पर AI स्क्रिप्ट्स के लिए ₹1500 से ₹4000 प्रति स्क्रिप्ट आसानी से मिलते हैं।`,
    `ChatGPT और Gemini के प्रॉम्प्ट्स में हमेशा 'रोल, टार्गेट ऑडियंस और कॉल-टू-एक्शन' स्पेसिफाई करें।`,
    `आप चैट में भी मुझसे कोई खास प्रॉम्प्ट मांग सकते हैं, मैं तुरंत भेज दूंगा!`,
  ];

  // Request actual user camera/mic for real interactive video call
  useEffect(() => {
    let active = true;

    async function setupMedia() {
      try {
        if (callType === "video" && navigator.mediaDevices?.getUserMedia) {
          const stream = await navigator.mediaDevices.getUserMedia({
            video: true,
            audio: true,
          });
          if (active) {
            localStreamRef.current = stream;
            if (localVideoRef.current) {
              localVideoRef.current.srcObject = stream;
            }
          }
        }
      } catch (err) {
        console.warn("Camera/mic permission fallback:", err);
      }
    }

    setupMedia();

    // Call connection simulation
    const connectTimer = setTimeout(() => {
      setCallStatus("connected");
    }, 1500);

    return () => {
      active = false;
      clearTimeout(connectTimer);
      if (localStreamRef.current) {
        localStreamRef.current.getTracks().forEach((track) => track.stop());
      }
    };
  }, [callType]);

  // Duration timer
  useEffect(() => {
    if (callStatus !== "connected") return;
    const interval = setInterval(() => {
      setDuration((prev) => prev + 1);
    }, 1000);
    return () => clearInterval(interval);
  }, [callStatus]);

  // Rotate creator advice every 6 seconds to give real consulting feel
  useEffect(() => {
    if (callStatus !== "connected") return;
    const adviceInterval = setInterval(() => {
      setActiveTopicIndex((prev) => (prev + 1) % creatorAdvice.length);
      setIsSpeaking(true);
      setTimeout(() => setIsSpeaking(false), 4500);
    }, 6000);
    return () => clearInterval(adviceInterval);
  }, [callStatus]);

  const formatTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const remaining = secs % 60;
    return `${mins.toString().padStart(2, "0")}:${remaining.toString().padStart(2, "0")}`;
  };

  const toggleMic = () => {
    setIsMuted(!isMuted);
    if (localStreamRef.current) {
      localStreamRef.current.getAudioTracks().forEach((track) => {
        track.enabled = isMuted; // Toggle
      });
    }
  };

  const toggleVideo = () => {
    setIsVideoDisabled(!isVideoDisabled);
    if (localStreamRef.current) {
      localStreamRef.current.getVideoTracks().forEach((track) => {
        track.enabled = isVideoDisabled; // Toggle
      });
    }
  };

  return (
    <div
      id="active-call-screen"
      className="fixed inset-0 z-50 bg-[#09090b] text-white flex flex-col justify-between select-none"
    >
      {/* Top Header Bar */}
      <div className="relative z-20 p-4 flex items-center justify-between bg-gradient-to-b from-black/80 via-black/40 to-transparent">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full overflow-hidden border border-emerald-500/70 p-0.5">
            <img
              src={creator.avatar}
              alt={creator.name}
              referrerPolicy="no-referrer"
              className="w-full h-full rounded-full object-cover"
            />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-bold tracking-tight">{creator.name}</h2>
              <span className="px-1.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 font-bold text-[10px] border border-emerald-500/40">
                ₹1 लाइव
              </span>
            </div>
            <p className="text-xs text-zinc-400 font-mono">
              {callStatus === "connecting" ? "कॉल जुड़ रही है..." : formatTime(duration)}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            id="btn-call-switch-chat"
            onClick={() => onOpenChatWithCreator(creator)}
            className="p-2.5 rounded-full bg-zinc-800/80 hover:bg-zinc-700 text-zinc-300 hover:text-white transition-colors flex items-center gap-1.5 text-xs font-medium cursor-pointer"
            title="कॉल के दौरान चैट खोलें"
          >
            <MessageSquare className="w-4 h-4 text-pink-400" />
            <span className="hidden sm:inline">चैट</span>
          </button>
        </div>
      </div>

      {/* Main Call Stage */}
      <div className="relative flex-1 flex items-center justify-center overflow-hidden">
        {callType === "video" ? (
          /* Video Call Stage */
          <div className="relative w-full h-full flex items-center justify-center bg-zinc-950">
            {/* Creator's Remote Video (Rich Feed with Animation) */}
            <div className="relative w-full h-full max-w-4xl max-h-[85vh] mx-auto flex items-center justify-center overflow-hidden">
              <img
                src={creator.avatar}
                alt={creator.name}
                referrerPolicy="no-referrer"
                className={`w-full h-full object-cover filter brightness-[0.88] transition-transform duration-700 ${
                  isSpeaking ? "scale-102" : "scale-100"
                }`}
              />

              {/* Creator Speaking Ripples & Audio Wave */}
              {isSpeaking && (
                <div className="absolute top-6 left-6 flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-black/60 backdrop-blur-md border border-emerald-500/50 text-emerald-400 text-xs font-semibold animate-pulse">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                  <span>{creator.name} बोल रहे हैं...</span>
                </div>
              )}

              {/* Creator Live Guidance Subtitle / Speech Bubble */}
              <div className="absolute bottom-6 inset-x-4 max-w-xl mx-auto p-4 rounded-2xl bg-black/75 backdrop-blur-md border border-zinc-700/70 shadow-2xl text-center">
                <div className="flex items-center justify-center gap-1.5 text-pink-400 text-xs font-bold mb-1">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>AI कमाई 1-on-1 लाइव परामर्श</span>
                </div>
                <p className="text-sm font-medium text-white leading-relaxed">
                  "{creatorAdvice[activeTopicIndex]}"
                </p>
              </div>
            </div>

            {/* Self Camera PiP (Picture in Picture) */}
            <div
              id="self-camera-pip"
              className="absolute top-4 right-4 w-28 sm:w-36 h-40 sm:h-52 bg-zinc-900 rounded-2xl border-2 border-emerald-500/80 overflow-hidden shadow-2xl z-30"
            >
              {!isVideoDisabled ? (
                <video
                  ref={localVideoRef}
                  autoPlay
                  playsInline
                  muted
                  className="w-full h-full object-cover transform -scale-x-100"
                />
              ) : (
                <div className="w-full h-full flex flex-col items-center justify-center bg-zinc-900 text-zinc-500">
                  <VideoOff className="w-6 h-6 mb-1" />
                  <span className="text-[10px]">कैमरा बंद</span>
                </div>
              )}
              <div className="absolute bottom-1.5 left-2 bg-black/70 px-1.5 py-0.5 rounded text-[10px] text-zinc-300">
                आप (You)
              </div>
            </div>
          </div>
        ) : (
          /* Audio Call Stage */
          <div className="flex flex-col items-center justify-center p-6 space-y-6 text-center">
            {/* Audio Pulsing Avatar Ring */}
            <div className="relative">
              <div
                className={`w-36 h-36 rounded-full p-1 bg-gradient-to-tr from-emerald-500 via-teal-500 to-green-500 shadow-2xl ${
                  isSpeaking ? "animate-pulse ring-8 ring-emerald-500/20" : ""
                }`}
              >
                <img
                  src={creator.avatar}
                  alt={creator.name}
                  referrerPolicy="no-referrer"
                  className="w-full h-full rounded-full object-cover"
                />
              </div>

              {/* Pulsing Audio Waveform Indicator */}
              <div className="absolute -bottom-3 inset-x-0 flex items-center justify-center gap-1">
                {[12, 24, 18, 28, 14, 22, 10].map((h, i) => (
                  <span
                    key={i}
                    className="w-1 bg-emerald-400 rounded-full transition-all duration-150"
                    style={{
                      height: isSpeaking ? `${h}px` : "6px",
                      opacity: isSpeaking ? 1 : 0.4,
                    }}
                  />
                ))}
              </div>
            </div>

            <div className="space-y-1">
              <h3 className="text-xl font-bold text-white">{creator.name}</h3>
              <p className="text-xs text-emerald-400 font-medium">
                {creator.expertise} • ₹1 ऑडियो कॉल
              </p>
              <p className="text-xs text-zinc-400 pt-1 font-mono">
                {callStatus === "connecting" ? "कनेक्ट हो रहा है..." : formatTime(duration)}
              </p>
            </div>

            {/* Spoken Advice in Audio Call */}
            <div className="max-w-md p-4 rounded-2xl bg-zinc-900/90 border border-zinc-800 shadow-lg">
              <p className="text-xs text-zinc-300 leading-relaxed italic">
                "{creatorAdvice[activeTopicIndex]}"
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Bottom Control Bar */}
      <div className="relative z-20 p-6 pb-8 bg-gradient-to-t from-black via-black/80 to-transparent">
        <div className="max-w-md mx-auto flex items-center justify-center gap-4 sm:gap-6">
          {/* Mute Button */}
          <button
            id="btn-call-toggle-mic"
            onClick={toggleMic}
            className={`p-4 rounded-full transition-all duration-200 active:scale-95 cursor-pointer ${
              isMuted
                ? "bg-rose-500/20 text-rose-400 border border-rose-500/50"
                : "bg-zinc-800/90 hover:bg-zinc-700 text-white"
            }`}
            title={isMuted ? "अनम्यूट करें" : "म्यूट करें"}
          >
            {isMuted ? <MicOff className="w-6 h-6" /> : <Mic className="w-6 h-6" />}
          </button>

          {/* Video Toggle (If Video Call) */}
          {callType === "video" && (
            <button
              id="btn-call-toggle-video"
              onClick={toggleVideo}
              className={`p-4 rounded-full transition-all duration-200 active:scale-95 cursor-pointer ${
                isVideoDisabled
                  ? "bg-rose-500/20 text-rose-400 border border-rose-500/50"
                  : "bg-zinc-800/90 hover:bg-zinc-700 text-white"
              }`}
              title={isVideoDisabled ? "कैमरा चालू करें" : "कैमरा बंद करें"}
            >
              {isVideoDisabled ? (
                <VideoOff className="w-6 h-6" />
              ) : (
                <VideoIcon className="w-6 h-6" />
              )}
            </button>
          )}

          {/* Speaker Button */}
          <button
            id="btn-call-toggle-speaker"
            onClick={() => setIsSpeakerOn(!isSpeakerOn)}
            className={`p-4 rounded-full transition-all duration-200 active:scale-95 cursor-pointer ${
              !isSpeakerOn
                ? "bg-zinc-800 text-zinc-400"
                : "bg-zinc-800/90 hover:bg-zinc-700 text-white"
            }`}
            title="स्पीकर टॉगल"
          >
            {isSpeakerOn ? <Volume2 className="w-6 h-6" /> : <VolumeX className="w-6 h-6" />}
          </button>

          {/* End Call Button (Red) */}
          <button
            id="btn-call-end"
            onClick={onEndCall}
            className="p-4 rounded-full bg-rose-600 hover:bg-rose-700 text-white shadow-lg shadow-rose-900/60 transition-all duration-200 active:scale-95 cursor-pointer"
            title="कॉल समाप्त करें"
          >
            <PhoneOff className="w-6 h-6" />
          </button>
        </div>

        <p className="text-center text-[10px] text-zinc-500 mt-3 font-medium">
          ₹1 प्रति कॉल सेशन • AI कमाई लाइव ऑडियो/वीडियो परामर्श
        </p>
      </div>
    </div>
  );
};
