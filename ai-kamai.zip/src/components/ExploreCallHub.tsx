import React from "react";
import { Phone, Video, Star, Sparkles, ShieldCheck, TrendingUp } from "lucide-react";
import { Creator } from "../types";

interface ExploreCallHubProps {
  creators: Creator[];
  onCallCreator: (creator: Creator, callType: "audio" | "video") => void;
  onChatCreator: (creator: Creator) => void;
}

export const ExploreCallHub: React.FC<ExploreCallHubProps> = ({
  creators,
  onCallCreator,
  onChatCreator,
}) => {
  return (
    <div id="explore-call-hub" className="max-w-2xl mx-auto px-4 py-4 space-y-4">
      {/* Promotional Banner */}
      <div className="p-4 rounded-3xl bg-gradient-to-r from-emerald-950/80 via-teal-950/80 to-zinc-900 border border-emerald-500/50 shadow-xl">
        <div className="flex items-center gap-2 text-emerald-400 font-bold text-xs uppercase tracking-wider mb-1">
          <Sparkles className="w-4 h-4" />
          <span>विशेष ₹1 ऑफर • 1-on-1 लाइव कंसल्टेशन</span>
        </div>
        <h2 className="text-lg sm:text-xl font-black text-white leading-tight">
          सिर्फ ₹1 देकर AI एक्सपर्ट से ऑडियो व वीडियो कॉल करें
        </h2>
        <p className="text-xs text-zinc-300 mt-1.5 leading-relaxed">
          ChatGPT प्रॉम्प्ट्स, यूट्यूब वीडियो स्क्रिप्ट्स, AI थंबनेल्स और क्लाइंट्स से पहली ₹10,000 की कमाई सीखें।
        </p>
      </div>

      {/* Creators Grid */}
      <div className="space-y-3">
        <h3 className="text-xs font-bold text-zinc-400 uppercase tracking-wider px-1">
          उपलब्ध AI कमाई मेंटर्स ({creators.length})
        </h3>

        {creators.map((creator) => (
          <div
            key={creator.id}
            id={`creator-card-${creator.id}`}
            className="p-4 rounded-2xl bg-[#121216] border border-zinc-800 hover:border-zinc-700/80 transition-all space-y-3"
          >
            {/* Top row */}
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="relative">
                  <img
                    src={creator.avatar}
                    alt={creator.name}
                    referrerPolicy="no-referrer"
                    className="w-13 h-13 rounded-full object-cover border-2 border-emerald-500/70"
                  />
                  {creator.isOnline && (
                    <span className="absolute bottom-0 right-0 w-3.5 h-3.5 bg-emerald-500 border-2 border-[#121216] rounded-full" />
                  )}
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <h4 className="font-bold text-sm text-white">{creator.name}</h4>
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                  </div>
                  <p className="text-xs text-zinc-400 font-medium">@{creator.handle}</p>
                  <div className="flex items-center gap-2 mt-1 text-[11px] text-zinc-400">
                    <span className="flex items-center gap-0.5 text-amber-400 font-semibold">
                      <Star className="w-3 h-3 fill-amber-400" /> {creator.rating}
                    </span>
                    <span>• {creator.totalCallsCompleted}+ कॉल्स</span>
                    <span className="text-emerald-400 font-semibold">• {creator.location}</span>
                  </div>
                </div>
              </div>

              {/* Price Tag */}
              <div className="text-right bg-emerald-950/60 border border-emerald-500/40 px-3 py-1.5 rounded-xl">
                <span className="text-base font-black text-emerald-400">₹1</span>
                <span className="block text-[9px] text-emerald-300 font-medium">कॉल शुल्क</span>
              </div>
            </div>

            {/* Bio */}
            <p className="text-xs text-zinc-300 leading-relaxed">{creator.bio}</p>

            {/* Specialty chips */}
            <div className="flex flex-wrap gap-1.5">
              {creator.specialtyChips.map((chip, idx) => (
                <span
                  key={idx}
                  className="px-2 py-0.5 rounded-md bg-zinc-800 text-[10px] text-zinc-300 font-medium border border-zinc-700/50"
                >
                  {chip}
                </span>
              ))}
            </div>

            {/* Action Buttons: Audio ₹1, Video ₹1, Chat */}
            <div className="grid grid-cols-3 gap-2 pt-1 border-t border-zinc-800/80">
              <button
                type="button"
                id={`btn-explore-audio-${creator.id}`}
                onClick={() => onCallCreator(creator, "audio")}
                className="py-2 px-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer border border-zinc-700/60"
              >
                <Phone className="w-3.5 h-3.5 text-emerald-400" />
                <span>ऑडियो ₹1</span>
              </button>

              <button
                type="button"
                id={`btn-explore-video-${creator.id}`}
                onClick={() => onCallCreator(creator, "video")}
                className="py-2 px-2 rounded-xl bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-500 hover:to-green-500 text-white text-xs font-bold flex items-center justify-center gap-1.5 shadow-sm shadow-emerald-950 transition-all active:scale-95 cursor-pointer"
              >
                <Video className="w-3.5 h-3.5" />
                <span>वीडियो ₹1</span>
              </button>

              <button
                type="button"
                id={`btn-explore-chat-${creator.id}`}
                onClick={() => onChatCreator(creator)}
                className="py-2 px-2 rounded-xl bg-zinc-800/80 hover:bg-zinc-700 text-pink-400 text-xs font-semibold flex items-center justify-center gap-1 transition-colors cursor-pointer border border-zinc-700/60"
              >
                <span>SMS चैट</span>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
