import React, { useEffect, useState } from "react";
import { X, PhoneCall, Sparkles, Heart } from "lucide-react";
import { Story, Creator } from "../types";

interface StoryViewerProps {
  story: Story;
  creator?: Creator;
  onClose: () => void;
  onCallCreator: (creator: Creator) => void;
}

export const StoryViewer: React.FC<StoryViewerProps> = ({
  story,
  creator,
  onClose,
  onCallCreator,
}) => {
  const [progress, setProgress] = useState(0);
  const [liked, setLiked] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(timer);
          onClose();
          return 100;
        }
        return prev + 2;
      });
    }, 100);

    return () => clearInterval(timer);
  }, [onClose]);

  return (
    <div
      id="story-modal-overlay"
      className="fixed inset-0 z-50 bg-black/95 flex items-center justify-center p-0 sm:p-4 backdrop-blur-md"
    >
      <div className="relative w-full max-w-md h-full sm:h-[88vh] sm:rounded-2xl overflow-hidden bg-zinc-900 flex flex-col justify-between shadow-2xl">
        {/* Background Image / Story Media */}
        <div className="absolute inset-0">
          <img
            src={story.mediaUrl}
            alt={story.creatorName}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-transparent to-black/90" />
        </div>

        {/* Top Header & Progress */}
        <div className="relative z-10 p-4 space-y-3">
          {/* Progress Bar */}
          <div className="w-full h-1 bg-white/30 rounded-full overflow-hidden">
            <div
              className="h-full bg-white transition-all duration-100 ease-linear rounded-full"
              style={{ width: `${progress}%` }}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <img
                src={story.creatorAvatar}
                alt={story.creatorName}
                referrerPolicy="no-referrer"
                className="w-9 h-9 rounded-full object-cover border border-white/40"
              />
              <div>
                <p className="text-sm font-semibold text-white leading-tight">
                  {story.creatorName}
                </p>
                <p className="text-[11px] text-zinc-300">{story.timestamp}</p>
              </div>
            </div>

            <button
              id="btn-close-story"
              onClick={onClose}
              className="p-1.5 rounded-full bg-black/40 hover:bg-black/70 text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Center / Earnings Badge */}
        {story.earningsShowcase && (
          <div className="relative z-10 mx-auto px-4 py-2 rounded-xl bg-emerald-950/80 border border-emerald-500/50 backdrop-blur-md text-emerald-300 font-bold text-sm flex items-center gap-2 shadow-lg animate-pulse">
            <Sparkles className="w-4 h-4 text-emerald-400" />
            <span>{story.earningsShowcase}</span>
          </div>
        )}

        {/* Bottom Story Controls & ₹1 Call CTA */}
        <div className="relative z-10 p-4 space-y-3">
          <p className="text-white text-sm font-medium leading-snug drop-shadow-md">
            {story.caption}
          </p>

          <div className="flex items-center gap-2.5 pt-2">
            {creator && (
              <button
                id="btn-story-call-1rs"
                onClick={() => {
                  onClose();
                  onCallCreator(creator);
                }}
                className="flex-1 py-2.5 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-500 hover:to-green-500 text-white font-bold text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-950/50 active:scale-98 transition-all"
              >
                <PhoneCall className="w-4 h-4" />
                <span>₹1 में ऑडियो / वीडियो कॉल करें</span>
              </button>
            )}

            <button
              id="btn-story-like"
              onClick={() => setLiked(!liked)}
              className="p-2.5 rounded-xl bg-white/20 hover:bg-white/30 backdrop-blur-md text-white transition-colors"
            >
              <Heart
                className={`w-5 h-5 transition-transform active:scale-125 ${
                  liked ? "text-rose-500 fill-rose-500" : ""
                }`}
              />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
