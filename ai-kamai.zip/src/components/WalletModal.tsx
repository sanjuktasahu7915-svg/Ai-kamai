import React, { useState } from "react";
import {
  X,
  Wallet,
  ArrowDownLeft,
  ArrowUpRight,
  PlusCircle,
  CreditCard,
  QrCode,
  ShieldCheck,
  CheckCircle2,
  Clock,
  Sparkles,
  ChevronRight,
  TrendingUp,
  Copy,
  Check,
} from "lucide-react";
import confetti from "canvas-confetti";
import { Transaction } from "../types";
import { PhonePeQrCard } from "./PhonePeQrCard";

interface WalletModalProps {
  walletBalance: number;
  earningsBalance: number;
  transactions: Transaction[];
  onClose: () => void;
  onAddMoney: (amount: number, method: "UPI" | "GPay" | "PhonePe" | "Paytm" | "Card") => void;
  onWithdraw: (amount: number, upiId: string) => void;
}

export const WalletModal: React.FC<WalletModalProps> = ({
  walletBalance,
  earningsBalance,
  transactions,
  onClose,
  onAddMoney,
  onWithdraw,
}) => {
  const [activeTab, setActiveTab] = useState<"wallet" | "methods" | "withdraw">("wallet");
  const [addAmount, setAddAmount] = useState<number>(10);
  const [selectedMethod, setSelectedMethod] = useState<
    "UPI" | "GPay" | "PhonePe" | "Paytm" | "Card"
  >("PhonePe");
  const [withdrawAmount, setWithdrawAmount] = useState<string>("100");
  const [withdrawUpi, setWithdrawUpi] = useState<string>("9668474743-4@ybl");
  const [feedbackMsg, setFeedbackMsg] = useState<string>("");
  const [showMethodsQr, setShowMethodsQr] = useState<boolean>(true);
  const [copiedMethodsUpi, setCopiedMethodsUpi] = useState<boolean>(false);

  const phonepeId = "9668474743-4@ybl";
  const bankAccount = "State Bank of India - 2788";

  const handleCopyId = async () => {
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(phonepeId);
      }
      setCopiedMethodsUpi(true);
      setTimeout(() => setCopiedMethodsUpi(false), 2000);
    } catch {
      setCopiedMethodsUpi(true);
      setTimeout(() => setCopiedMethodsUpi(false), 2000);
    }
  };

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (addAmount < 1) return;

    onAddMoney(addAmount, selectedMethod);
    try {
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.6 },
      });
    } catch (e) {}

    setFeedbackMsg(`₹${addAmount} आपके AI कमाई वॉलेट में सफलतापूर्वक जोड़े गए!`);
    setTimeout(() => setFeedbackMsg(""), 3500);
  };

  const handleWithdrawSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(withdrawAmount);
    if (isNaN(amt) || amt <= 0 || amt > earningsBalance) {
      alert("अमान्य निकासी राशि या अपर्याप्त कमाई बैलेंस");
      return;
    }

    onWithdraw(amt, withdrawUpi);
    setFeedbackMsg(`₹${amt} का निकासी अनुरोध आपके UPI (${withdrawUpi}) पर भेज दिया गया है!`);
    setTimeout(() => setFeedbackMsg(""), 4000);
  };

  return (
    <div
      id="wallet-modal-overlay"
      className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 text-white"
    >
      <div className="relative w-full max-w-lg bg-[#131317] border border-zinc-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="bg-gradient-to-r from-zinc-900 via-zinc-800 to-zinc-900 px-5 py-4 border-b border-zinc-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-emerald-500/20 flex items-center justify-center text-emerald-400 border border-emerald-500/40">
              <Wallet className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-base leading-tight">AI कमाई वॉलेट & पेमेंट</h3>
              <p className="text-[11px] text-zinc-400">सुरक्षित UPI व कार्ड भुगतान</p>
            </div>
          </div>
          <button
            id="btn-close-wallet-modal"
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-zinc-800 text-zinc-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="grid grid-cols-3 border-b border-zinc-800 bg-[#0e0e11] text-xs font-semibold">
          <button
            type="button"
            id="tab-btn-wallet"
            onClick={() => setActiveTab("wallet")}
            className={`py-3 text-center transition-colors cursor-pointer ${
              activeTab === "wallet"
                ? "text-emerald-400 border-b-2 border-emerald-500 bg-zinc-800/40"
                : "text-zinc-400 hover:text-zinc-200"
            }`}
          >
            वॉलेट बैलेंस
          </button>
          <button
            type="button"
            id="tab-btn-methods"
            onClick={() => setActiveTab("methods")}
            className={`py-3 text-center transition-colors cursor-pointer ${
              activeTab === "methods"
                ? "text-emerald-400 border-b-2 border-emerald-500 bg-zinc-800/40"
                : "text-zinc-400 hover:text-zinc-200"
            }`}
          >
            पेमेंट मेथड
          </button>
          <button
            type="button"
            id="tab-btn-withdraw"
            onClick={() => setActiveTab("withdraw")}
            className={`py-3 text-center transition-colors cursor-pointer ${
              activeTab === "withdraw"
                ? "text-emerald-400 border-b-2 border-emerald-500 bg-zinc-800/40"
                : "text-zinc-400 hover:text-zinc-200"
            }`}
          >
            पैसे निकालें
          </button>
        </div>

        {/* Feedback Alert */}
        {feedbackMsg && (
          <div className="mx-4 mt-3 p-3 rounded-xl bg-emerald-950/90 border border-emerald-500/70 text-emerald-200 text-xs font-medium flex items-center gap-2 animate-in fade-in">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
            <span>{feedbackMsg}</span>
          </div>
        )}

        {/* Content Body */}
        <div className="p-5 flex-1 overflow-y-auto space-y-5">
          {activeTab === "wallet" && (
            <>
              {/* Dual Balance Cards */}
              <div className="grid grid-cols-2 gap-3">
                {/* Wallet Balance Card */}
                <div className="p-4 rounded-2xl bg-gradient-to-br from-emerald-950/80 to-teal-950/60 border border-emerald-500/40 shadow-lg">
                  <div className="flex items-center justify-between text-xs text-emerald-300 mb-1">
                    <span>वॉलेट बैलेंस</span>
                    <Wallet className="w-4 h-4 text-emerald-400" />
                  </div>
                  <div className="text-2xl font-black text-white">₹{walletBalance}</div>
                  <p className="text-[10px] text-emerald-300/80 mt-1">
                    ₹1 कॉल्स अनलॉक करने के लिए प्रयुक्त
                  </p>
                </div>

                {/* Earnings Balance Card */}
                <div className="p-4 rounded-2xl bg-gradient-to-br from-pink-950/80 to-purple-950/60 border border-pink-500/40 shadow-lg">
                  <div className="flex items-center justify-between text-xs text-pink-300 mb-1">
                    <span>कुल कमाई</span>
                    <TrendingUp className="w-4 h-4 text-pink-400" />
                  </div>
                  <div className="text-2xl font-black text-white">₹{earningsBalance}</div>
                  <p className="text-[10px] text-pink-300/80 mt-1">
                    कंटेंट और रेफरल से अर्जित
                  </p>
                </div>
              </div>

              {/* Add Money Section */}
              <div className="p-4 rounded-2xl bg-zinc-900/90 border border-zinc-800 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-xs text-zinc-200 flex items-center gap-1.5">
                    <PlusCircle className="w-3.5 h-3.5 text-emerald-400" />
                    <span>वॉलेट में पैसे जोड़ें (Add Money)</span>
                  </h4>
                  <span className="text-[10px] text-zinc-400">न्यूनतम: ₹1</span>
                </div>

                {/* Amount Quick Select Chips */}
                <div className="grid grid-cols-4 gap-2">
                  {[1, 10, 50, 100].map((amt) => (
                    <button
                      key={amt}
                      type="button"
                      onClick={() => setAddAmount(amt)}
                      className={`py-2 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                        addAmount === amt
                          ? "bg-emerald-600 border-emerald-500 text-white shadow-md shadow-emerald-950"
                          : "bg-zinc-800/80 border-zinc-700 text-zinc-300 hover:bg-zinc-700"
                      }`}
                    >
                      ₹{amt}
                    </button>
                  ))}
                </div>

                {/* Method selector for adding */}
                <div className="flex items-center gap-2 pt-1">
                  <select
                    value={selectedMethod}
                    onChange={(e) => setSelectedMethod(e.target.value as any)}
                    className="flex-1 bg-zinc-800 border border-zinc-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-purple-500"
                  >
                    <option value="PhonePe">PhonePe (UPI: 9668474743-4@ybl)</option>
                    <option value="GPay">Google Pay (UPI)</option>
                    <option value="Paytm">Paytm (UPI)</option>
                    <option value="Card">डेबिट / क्रेडिट कार्ड</option>
                  </select>

                  <button
                    type="button"
                    id="btn-recharge-submit"
                    onClick={handleAddSubmit}
                    className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-zinc-950 font-bold text-xs transition-colors cursor-pointer"
                  >
                    ₹{addAmount} जोड़ें
                  </button>
                </div>
              </div>

              {/* Transaction History */}
              <div className="space-y-2.5">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-xs text-zinc-300">लेनदेन का इतिहास (Transactions)</h4>
                  <span className="text-[10px] text-zinc-500">हालिया रिकॉर्ड्स</span>
                </div>

                <div className="space-y-2">
                  {transactions.map((tx) => (
                    <div
                      key={tx.id}
                      className="p-3 rounded-xl bg-zinc-900/60 border border-zinc-800 flex items-center justify-between text-xs"
                    >
                      <div className="flex items-center gap-2.5">
                        <div
                          className={`w-7 h-7 rounded-lg flex items-center justify-center ${
                            tx.type === "wallet_recharge" || tx.type === "referral_bonus"
                              ? "bg-emerald-500/20 text-emerald-400"
                              : "bg-rose-500/20 text-rose-400"
                          }`}
                        >
                          {tx.type === "wallet_recharge" || tx.type === "referral_bonus" ? (
                            <ArrowDownLeft className="w-4 h-4" />
                          ) : (
                            <ArrowUpRight className="w-4 h-4" />
                          )}
                        </div>
                        <div>
                          <p className="font-semibold text-zinc-200">{tx.title}</p>
                          <p className="text-[10px] text-zinc-400">
                            {tx.subtitle} • {tx.timestamp}
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <span
                          className={`font-bold ${
                            tx.type === "wallet_recharge" || tx.type === "referral_bonus"
                              ? "text-emerald-400"
                              : "text-zinc-200"
                          }`}
                        >
                          {tx.type === "wallet_recharge" || tx.type === "referral_bonus" ? "+" : "-"}₹
                          {tx.amount}
                        </span>
                        <span className="block text-[9px] text-emerald-500 font-medium">सफल</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}

          {activeTab === "methods" && (
            <div className="space-y-4">
              <p className="text-xs text-zinc-400 leading-relaxed">
                ऑडियो/वीडियो कॉल के ₹1 भुगतान प्राप्त करने व वॉलेट रिचार्ज के लिए उपलब्ध पेमेंट खाते:
              </p>

              {/* Primary PhonePe & SBI Account Card */}
              <div className="p-4 rounded-2xl bg-zinc-900 border-2 border-[#5f259f]/70 space-y-3.5 shadow-lg shadow-purple-950/40">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-xl bg-[#5f259f] flex items-center justify-center text-white font-black text-sm shadow">
                      पे
                    </div>
                    <div>
                      <h4 className="font-bold text-xs text-white">
                        PhonePe (प्राथमिक प्राप्तकर्ता खाता)
                      </h4>
                      <p className="text-[10px] text-purple-300">
                        Primary account for receiving money
                      </p>
                    </div>
                  </div>
                  <span className="text-[10px] text-emerald-400 font-bold bg-emerald-500/10 border border-emerald-500/30 px-2 py-0.5 rounded-full flex items-center gap-1">
                    <Check className="w-3 h-3 text-emerald-400" /> सक्रिय (Active)
                  </span>
                </div>

                {/* Bank details row */}
                <div className="p-2.5 rounded-xl bg-zinc-800/80 border border-zinc-700/60 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2.5">
                    <div className="w-7 h-7 rounded-full bg-[#0082c6] text-white font-black text-[10px] flex items-center justify-center shadow-sm">
                      SBI
                    </div>
                    <div>
                      <p className="font-bold text-zinc-100 text-[11px]">{bankAccount}</p>
                      <p className="text-[10px] text-zinc-400">प्राथमिक बैंक खाता • ₹1 कॉल शुल्क प्राप्ति हेतु</p>
                    </div>
                  </div>
                </div>

                {/* UPI ID Row */}
                <div className="p-2.5 rounded-xl bg-zinc-950/80 border border-zinc-800 flex items-center justify-between text-xs">
                  <div>
                    <span className="text-[9px] uppercase tracking-wider text-zinc-400 font-bold block">
                      PhonePe UPI ID
                    </span>
                    <span className="font-mono text-xs font-bold text-purple-200 select-all">
                      {phonepeId}
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={handleCopyId}
                    className="px-2.5 py-1 rounded-lg bg-[#5f259f] hover:bg-[#7b2cbf] text-white text-[11px] font-bold flex items-center gap-1 cursor-pointer transition-colors"
                  >
                    {copiedMethodsUpi ? (
                      <>
                        <Check className="w-3 h-3 text-emerald-300" />
                        <span>कॉपी हुआ!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3" />
                        <span>कॉपी</span>
                      </>
                    )}
                  </button>
                </div>

                {/* QR Code toggle */}
                <div className="pt-1">
                  <button
                    type="button"
                    onClick={() => setShowMethodsQr(!showMethodsQr)}
                    className="w-full py-2 rounded-xl bg-zinc-800/60 hover:bg-zinc-800 border border-zinc-700/50 flex items-center justify-center gap-2 text-xs text-zinc-300 transition-colors cursor-pointer"
                  >
                    <QrCode className="w-3.5 h-3.5 text-purple-400" />
                    <span>{showMethodsQr ? "PhonePe QR कोड छुपाएं" : "PhonePe QR कोड देखें"}</span>
                  </button>
                </div>

                {showMethodsQr && (
                  <div className="pt-2 animate-in fade-in zoom-in-95 duration-200">
                    <PhonePeQrCard amount={1} note="AI Kamai Call Unlock" showPayLink={false} />
                  </div>
                )}
              </div>

              {/* Other supported gateways */}
              <div className="p-3 rounded-2xl bg-zinc-900 border border-zinc-800 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <CreditCard className="w-4 h-4 text-emerald-400" />
                    <span className="text-xs font-bold text-white">अन्य सपोर्टेड गेटवे</span>
                  </div>
                  <span className="text-[10px] text-zinc-400">Google Pay, Paytm, BHIM, Cards</span>
                </div>
                <p className="text-[11px] text-zinc-400">
                  सभी UPI ऐप्स से सीधे ₹1 ट्रांसफर संभव है।
                </p>
              </div>

              {/* Security info */}
              <div className="p-3 rounded-2xl bg-emerald-950/40 border border-emerald-500/30 flex items-center gap-2.5 text-xs text-emerald-300">
                <ShieldCheck className="w-5 h-5 text-emerald-400 flex-shrink-0" />
                <p className="text-[11px]">
                  256-बिट सुरक्षित भुगतान प्रणाली। कोई भी कॉल करेगा तो ₹1 सीधे आपके इस PhonePe खाते में प्राप्त होगा।
                </p>
              </div>
            </div>
          )}

          {activeTab === "withdraw" && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-gradient-to-r from-pink-950/80 to-purple-950/60 border border-pink-500/40">
                <span className="text-xs text-pink-300">उपलब्ध निकासी योग्य कमाई:</span>
                <div className="text-2xl font-black text-white mt-0.5">₹{earningsBalance}</div>
                <p className="text-[10px] text-pink-300/80 mt-1">
                  सीधे आपके प्राथमिक PhonePe खाते में ट्रांसफर की जाएगी।
                </p>
              </div>

              {/* Preset Account info */}
              <div className="p-3 rounded-xl bg-purple-950/40 border border-purple-800/40 flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-lg bg-[#5f259f] flex items-center justify-center text-white text-[10px] font-bold">
                    पे
                  </div>
                  <div>
                    <p className="text-[11px] font-bold text-white leading-tight">
                      {bankAccount}
                    </p>
                    <p className="text-[10px] text-zinc-400">प्राथमिक निकासी UPI: {phonepeId}</p>
                  </div>
                </div>
                <span className="text-[10px] text-emerald-400 font-bold bg-emerald-500/10 px-2 py-0.5 rounded-full">
                  वेरिफाइड
                </span>
              </div>

              <form onSubmit={handleWithdrawSubmit} className="space-y-3">
                <div>
                  <label className="text-xs font-semibold text-zinc-300 block mb-1">
                    निकासी राशि (Withdrawal Amount):
                  </label>
                  <input
                    type="number"
                    value={withdrawAmount}
                    onChange={(e) => setWithdrawAmount(e.target.value)}
                    max={earningsBalance}
                    min="1"
                    className="w-full bg-zinc-900 border border-zinc-700 rounded-xl px-3 py-2.5 text-sm text-white focus:outline-none focus:border-pink-500"
                    placeholder="उदा: 100"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-zinc-300 block mb-1">
                    PhonePe UPI ID (प्राथमिक खाता):
                  </label>
                  <input
                    type="text"
                    value={withdrawUpi}
                    onChange={(e) => setWithdrawUpi(e.target.value)}
                    className="w-full bg-zinc-900 border border-zinc-700 rounded-xl px-3 py-2.5 text-sm text-white font-mono focus:outline-none focus:border-purple-500"
                    placeholder="उदा: 9668474743-4@ybl"
                  />
                </div>

                <button
                  type="submit"
                  disabled={earningsBalance <= 0}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white font-bold text-xs transition-all active:scale-98 disabled:opacity-50 cursor-pointer shadow-md shadow-purple-950"
                >
                  ₹{withdrawAmount || "0"} PhonePe ({phonepeId}) में ट्रांसफर करें
                </button>
              </form>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
