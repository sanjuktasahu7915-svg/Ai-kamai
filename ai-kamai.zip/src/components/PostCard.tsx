import React, { useState } from "react";
import {
  Heart,
  MessageCircle,
  Send,
  Bookmark,
  MoreHorizontal,
  Phone,
  Video,
  Sparkles,
  Share2,
} from "lucide-react";
import { Post, Creator } from "../types";

interface PostCardProps {
  post: Post;
  creator?: Creator;
  onCallClick: (creator: Creator, preferredType?: "audio" | "video") => void;
  onOpenChat: (creator: Creator) => void;
  onLikeToggle: (postId: string) => void;
  onSaveToggle: (postId: string) => void;
  onAddComment: (postId: string, commentText: string) => void;
}

export const PostCard: React.FC<PostCardProps> = ({
  post,
  creator,
  onCallClick,
  onOpenChat,
  onLikeToggle,
  onSaveToggle,
  onAddComment,
}) => {
  const [showComments, setShowComments] = useState(false);
  const [commentInput, setCommentInput] = useState("");
  const [isCopied, setIsCopied] = useState(false);

  const handleCommentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentInput.trim()) return;
    onAddComment(post.id, commentInput.trim());
    setCommentInput("");
    setShowComments(true);
  };

  const handleShare = () => {
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  return (
    <article
      id={`post-card-${post.id}`}
      className="bg-[#0e0e11] border-b border-zinc-800/80 text-white pb-3 mb-2"
    >
      {/* Header: User Info & ₹1 Call Badge */}
      <div className="flex items-center justify-between px-3.5 py-3">
        <div className="flex items-center gap-2.5">
          <div className="relative p-[1.5px] rounded-full bg-gradient-to-tr from-amber-400 via-rose-500 to-fuchsia-600">
            <img
              src={post.creatorAvatar}
              alt={post.creatorHandle}
              referrerPolicy="no-referrer"
              className="w-9 h-9 rounded-full object-cover border border-[#0e0e11]"
            />
          </div>
          <div>
            <div className="flex items-center gap-1">
              <span className="text-sm font-semibold text-zinc-100 hover:underline cursor-pointer">
                {post.creatorHandle}
              </span>
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" title="ऑनलाइन" />
            </div>
            <p className="text-[11px] text-zinc-400">{post.location}</p>
          </div>
        </div>

        {/* Call Button & More Options */}
        <div className="flex items-center gap-2">
          {creator && (
            <button
              id={`btn-post-call-${post.id}`}
              onClick={() => onCallClick(creator)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-emerald-950/80 hover:bg-emerald-900 border border-emerald-500/70 text-emerald-400 font-bold text-xs shadow-sm shadow-emerald-950 transition-all active:scale-95 cursor-pointer"
              title="₹1 में ऑडियो या वीडियो कॉल करें"
            >
              <Phone className="w-3.5 h-3.5 fill-emerald-400/20" />
              <span>₹1</span>
            </button>
          )}

          <button
            id={`btn-post-menu-${post.id}`}
            onClick={() => onOpenChat(creator || {
              id: post.creatorId,
              name: post.creatorName,
              handle: post.creatorHandle,
              avatar: post.creatorAvatar,
              location: post.location,
              bio: post.caption,
              verified: true,
              isOnline: true,
              earningsThisMonth: 30000,
              followers: "50K",
              expertise: "AI Creator",
              audioCallPrice: 1,
              videoCallPrice: 1,
              rating: 4.9,
              totalCallsCompleted: 100,
              specialtyChips: ["AI Earn"],
            })}
            className="p-1.5 rounded-full text-zinc-400 hover:text-zinc-200 transition-colors"
            title="मैसेज / विकल्प"
          >
            <MoreHorizontal className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Post Media / Image */}
      <div className="relative bg-zinc-950 overflow-hidden select-none">
        <img
          src={post.postImage}
          alt={post.caption}
          referrerPolicy="no-referrer"
          className="w-full max-h-[500px] object-cover"
        />

        {/* In-image caption banner matching the user screenshot */}
        <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-black/90 via-black/60 to-transparent p-4 pt-10">
          <p className="text-white text-base font-semibold drop-shadow-md leading-snug">
            {post.caption}
          </p>
          {post.earningsBadge && (
            <div className="mt-2 inline-flex items-center gap-1 px-2.5 py-1 rounded-md bg-emerald-900/90 border border-emerald-500/60 text-emerald-200 text-xs font-bold">
              <Sparkles className="w-3 h-3 text-emerald-400" />
              <span>{post.earningsBadge}</span>
            </div>
          )}
        </div>
      </div>

      {/* Action Bar (Heart, Comment, Share, Bookmark) */}
      <div className="flex items-center justify-between px-3.5 py-2.5">
        <div className="flex items-center gap-4">
          {/* Like */}
          <button
            id={`btn-post-like-${post.id}`}
            onClick={() => onLikeToggle(post.id)}
            className="flex items-center gap-1.5 text-zinc-300 hover:text-white transition-colors group"
          >
            <Heart
              className={`w-6 h-6 transition-transform active:scale-125 ${
                post.isLiked ? "text-rose-500 fill-rose-500" : "group-hover:text-rose-400"
              }`}
            />
            <span className="text-xs font-semibold">{post.likes}</span>
          </button>

          {/* Comment */}
          <button
            id={`btn-post-comments-${post.id}`}
            onClick={() => setShowComments(!showComments)}
            className="flex items-center gap-1.5 text-zinc-300 hover:text-white transition-colors group"
          >
            <MessageCircle className="w-6 h-6 group-hover:text-blue-400" />
            <span className="text-xs font-semibold">{post.commentsCount}</span>
          </button>

          {/* Send / Direct Message */}
          <button
            id={`btn-post-dm-${post.id}`}
            onClick={() => creator && onOpenChat(creator)}
            className="text-zinc-300 hover:text-white transition-colors"
            title="क्रिएटर को डायरेक्ट SMS / DM भेजें"
          >
            <Send className="w-5 h-5 -rotate-12 hover:text-pink-400" />
          </button>

          {/* Share */}
          <button
            id={`btn-post-share-${post.id}`}
            onClick={handleShare}
            className="text-zinc-400 hover:text-zinc-200 text-xs flex items-center gap-1"
            title="शेयर करें"
          >
            <Share2 className="w-4 h-4" />
            {isCopied && <span className="text-emerald-400 text-[10px]">लिंक कॉपी हुआ!</span>}
          </button>
        </div>

        {/* Bookmark / Save */}
        <button
          id={`btn-post-save-${post.id}`}
          onClick={() => onSaveToggle(post.id)}
          className="text-zinc-300 hover:text-white transition-colors"
        >
          <Bookmark
            className={`w-5 h-5 ${
              post.isSaved ? "text-amber-400 fill-amber-400" : ""
            }`}
          />
        </button>
      </div>

      {/* Caption Content */}
      <div className="px-3.5 space-y-1.5">
        <p className="text-xs text-zinc-200 leading-relaxed">
          <span className="font-bold text-white mr-1.5">{post.creatorHandle}</span>
          {post.caption}
        </p>

        {post.tags && (
          <div className="flex flex-wrap gap-1.5 pt-0.5">
            {post.tags.map((tag, idx) => (
              <span key={idx} className="text-[11px] text-pink-400 hover:underline cursor-pointer">
                {tag}
              </span>
            ))}
          </div>
        )}

        <p className="text-[10px] text-zinc-500 uppercase tracking-wide pt-0.5">
          {post.timestamp}
        </p>
      </div>

      {/* Quick Action Ribbon: Call ₹1 */}
      {creator && (
        <div className="mx-3.5 mt-2.5 p-2 rounded-xl bg-gradient-to-r from-zinc-900 to-zinc-800/80 border border-zinc-700/60 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="flex h-2 w-2 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
            <span className="text-xs text-zinc-300">
              {creator.name} अभी लाइव हैं!
            </span>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              id={`btn-ribbon-audio-${post.id}`}
              onClick={() => onCallClick(creator, "audio")}
              className="px-2.5 py-1 rounded-lg bg-zinc-800 hover:bg-zinc-700 border border-zinc-600 text-xs font-medium text-zinc-200 flex items-center gap-1 cursor-pointer transition-colors"
            >
              <Phone className="w-3 h-3 text-emerald-400" />
              <span>ऑडियो ₹1</span>
            </button>
            <button
              id={`btn-ribbon-video-${post.id}`}
              onClick={() => onCallClick(creator, "video")}
              className="px-2.5 py-1 rounded-lg bg-emerald-700 hover:bg-emerald-600 text-xs font-semibold text-white flex items-center gap-1 shadow-sm cursor-pointer transition-colors"
            >
              <Video className="w-3 h-3 text-white" />
              <span>वीडियो ₹1</span>
            </button>
          </div>
        </div>
      )}

      {/* Comments Section */}
      {showComments && (
        <div className="mt-3 px-3.5 pt-2 border-t border-zinc-800 space-y-2">
          <p className="text-xs font-semibold text-zinc-400">कमेंट्स ({post.comments.length})</p>
          <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
            {post.comments.map((comm) => (
              <div key={comm.id} className="flex items-start gap-2 text-xs">
                <img
                  src={comm.userAvatar}
                  alt={comm.userName}
                  referrerPolicy="no-referrer"
                  className="w-6 h-6 rounded-full object-cover"
                />
                <div className="flex-1 bg-zinc-900/80 p-2 rounded-lg border border-zinc-800">
                  <span className="font-bold text-zinc-200 mr-1.5">{comm.userName}</span>
                  <span className="text-zinc-300">{comm.text}</span>
                  <p className="text-[10px] text-zinc-500 mt-1">{comm.timestamp}</p>
                </div>
              </div>
            ))}
          </div>

          {/* Add Comment Input */}
          <form onSubmit={handleCommentSubmit} className="flex items-center gap-2 pt-1">
            <input
              type="text"
              id={`input-comment-${post.id}`}
              value={commentInput}
              onChange={(e) => setCommentInput(e.target.value)}
              placeholder="एक कमेंट लिखें..."
              className="flex-1 bg-zinc-900 border border-zinc-700/80 rounded-full px-3 py-1.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-pink-500"
            />
            <button
              type="submit"
              disabled={!commentInput.trim()}
              className="text-xs font-bold text-pink-500 disabled:opacity-40 hover:text-pink-400 px-2 cursor-pointer"
            >
              पोस्ट
            </button>
          </form>
        </div>
      )}
    </article>
  );
};
