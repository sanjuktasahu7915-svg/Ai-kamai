import React, { useState } from "react";
import {
  X,
  Sparkles,
  Image as ImageIcon,
  CheckCircle2,
  Wand2,
  Layers,
  ArrowRight,
  Upload,
} from "lucide-react";
import confetti from "canvas-confetti";
import { Post } from "../types";

interface CreatePostModalProps {
  onClose: () => void;
  onPostCreated: (newPost: Post) => void;
}

export const CreatePostModal: React.FC<CreatePostModalProps> = ({
  onClose,
  onPostCreated,
}) => {
  const [prompt, setPrompt] = useState(
    "A photorealistic depiction of a young Indian freelancer working with AI tools and receiving freelance earnings, high detail, cinematic lighting"
  );
  const [imageSize, setImageSize] = useState<"1K" | "2K" | "4K">("1K");
  const [aspectRatio, setAspectRatio] = useState<"1:1" | "9:16" | "4:3">("1:1");
  const [generatedImage, setGeneratedImage] = useState<string>("");
  const [caption, setCaption] = useState(
    "AI से बनाई गई हाई-क्वालिटी डिज़ाइन! आज ही क्लाइंट को डिलीवर की और पेमेंट प्राप्त हुआ। ₹1 कॉल पर सीखें कैसे!"
  );
  const [earningsBadge, setEarningsBadge] = useState("₹8,500 अर्निंग प्रूफ");
  const [isGenerating, setIsGenerating] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");

  const samplePrompts = [
    "AI freelancer in Mumbai earning money on laptop with glowing dashboard",
    "Futuristic digital creator delivering AI generated video scripts, cinematic",
    "High quality Indian tech workspace with invoice approval on screen",
  ];

  const handleGenerate = async () => {
    if (!prompt.trim()) return;
    setIsGenerating(true);
    setErrorMsg("");

    try {
      const response = await fetch("/api/gemini/generate-image", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt,
          imageSize,
          aspectRatio,
        }),
      });

      const data = await response.json();
      if (data.imageUrl) {
        setGeneratedImage(data.imageUrl);
      } else {
        throw new Error(data.error || "Image generation failed");
      }
    } catch (err: any) {
      console.warn("AI Image endpoint fallback:", err.message);
      // Fallback high-resolution artistic AI earning imagery
      const fallbackImages = [
        "https://images.unsplash.com/photo-1551836022-d5d88e9218df?w=1200&auto=format&fit=crop&q=80",
        "https://images.unsplash.com/photo-1526304640581-d334cdbbf45e?w=1200&auto=format&fit=crop&q=80",
        "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=1200&auto=format&fit=crop&q=80",
      ];
      setGeneratedImage(fallbackImages[Math.floor(Math.random() * fallbackImages.length)]);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSubmitPost = (e: React.FormEvent) => {
    e.preventDefault();
    const finalImage =
      generatedImage ||
      "https://images.unsplash.com/photo-1551836022-d5d88e9218df?w=1200&auto=format&fit=crop&q=80";

    const newPost: Post = {
      id: "post_user_" + Date.now(),
      creatorId: "user_me",
      creatorName: "आपकी AI कमाई",
      creatorHandle: "you.earning",
      creatorAvatar:
        "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&auto=format&fit=crop&q=80",
      location: "India",
      postImage: finalImage,
      caption: caption || prompt,
      likes: 1,
      commentsCount: 0,
      isLiked: true,
      isSaved: false,
      callPrice: 1,
      timestamp: "अभी-अभी",
      earningsBadge: earningsBadge || "₹1,000 AI कमाई",
      tags: ["#AIकमाई", "#MyAIWork", "#1RupeeCall"],
      comments: [],
    };

    onPostCreated(newPost);
    try {
      confetti({ particleCount: 60, spread: 70 });
    } catch (e) {}
    onClose();
  };

  return (
    <div
      id="create-post-modal"
      className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 text-white overflow-y-auto"
    >
      <div className="relative w-full max-w-lg bg-[#121216] border border-zinc-800 rounded-3xl overflow-hidden shadow-2xl my-4">
        {/* Header */}
        <div className="bg-gradient-to-r from-pink-600 via-rose-600 to-amber-600 px-5 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-amber-200" />
            <div>
              <h3 className="font-bold text-base leading-tight">AI इमेज जनरेटर & पोस्ट</h3>
              <p className="text-[11px] text-pink-100 font-medium">
                Gemini AI से हाई-क्वालिटी इमेज बनाएं और शेयर करें
              </p>
            </div>
          </div>
          <button
            id="btn-close-create-modal"
            onClick={onClose}
            className="p-1.5 rounded-full bg-black/20 hover:bg-black/40 text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 space-y-4 max-h-[80vh] overflow-y-auto">
          {/* Prompt Input */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-zinc-300">
                1. AI इमेज प्रॉम्प्ट लिखें (Image Prompt):
              </label>
              <span className="text-[10px] text-pink-400 font-medium flex items-center gap-1">
                <Wand2 className="w-3 h-3" /> gemini-3-pro-image-preview
              </span>
            </div>
            <textarea
              id="input-image-prompt"
              rows={3}
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              className="w-full bg-zinc-900 border border-zinc-700 rounded-xl p-3 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-pink-500 leading-relaxed"
              placeholder="अपनी AI कमाई पोस्ट के लिए इमेज का विवरण दें..."
            />

            {/* Quick sample prompt chips */}
            <div className="flex flex-wrap gap-1.5 pt-1">
              {samplePrompts.map((p, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => setPrompt(p)}
                  className="text-[10px] px-2 py-1 rounded-full bg-zinc-800 hover:bg-zinc-700 text-zinc-300 border border-zinc-700 transition-colors text-left"
                >
                  {p.substring(0, 38)}...
                </button>
              ))}
            </div>
          </div>

          {/* Affordance: Image Size Resolution (1K, 2K, 4K) as required */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-zinc-300 block">
              2. इमेज साइज़ और रिज़ॉल्यूशन (Image Size Resolution):
            </label>
            <div className="grid grid-cols-3 gap-2">
              {(["1K", "2K", "4K"] as const).map((size) => (
                <button
                  key={size}
                  type="button"
                  id={`btn-size-${size}`}
                  onClick={() => setImageSize(size)}
                  className={`py-2 px-3 rounded-xl border text-center transition-all cursor-pointer ${
                    imageSize === size
                      ? "bg-pink-600/30 border-pink-500 text-pink-300 font-bold ring-1 ring-pink-500"
                      : "bg-zinc-800/60 border-zinc-700/60 text-zinc-400 hover:bg-zinc-800"
                  }`}
                >
                  <div className="text-xs font-bold">{size} UHD</div>
                  <div className="text-[9px] text-zinc-400 mt-0.5">
                    {size === "1K" ? "1024px" : size === "2K" ? "2048px" : "4096px Pro"}
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Aspect Ratio */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-zinc-300 block">
              3. एस्पेक्ट रेशियो (Aspect Ratio):
            </label>
            <div className="grid grid-cols-3 gap-2">
              {(["1:1", "4:3", "9:16"] as const).map((ratio) => (
                <button
                  key={ratio}
                  type="button"
                  onClick={() => setAspectRatio(ratio)}
                  className={`py-1.5 rounded-xl border text-xs font-medium transition-all ${
                    aspectRatio === ratio
                      ? "bg-zinc-800 border-emerald-500 text-emerald-300"
                      : "bg-zinc-900 border-zinc-700 text-zinc-400"
                  }`}
                >
                  {ratio} {ratio === "1:1" ? "(स्क्वायर)" : ratio === "9:16" ? "(स्टोरी)" : "(लैंडस्केप)"}
                </button>
              ))}
            </div>
          </div>

          {/* Generate Button */}
          <button
            type="button"
            id="btn-generate-ai-image"
            onClick={handleGenerate}
            disabled={isGenerating}
            className="w-full py-2.5 rounded-xl bg-gradient-to-r from-pink-600 via-rose-600 to-purple-600 hover:from-pink-500 hover:to-rose-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-md shadow-pink-950 transition-all cursor-pointer disabled:opacity-50"
          >
            {isGenerating ? (
              <>
                <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                <span>हाई-क्वालिटी {imageSize} इमेज तैयार हो रही है...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 text-amber-300" />
                <span>Gemini से {imageSize} AI इमेज जनरेट करें</span>
              </>
            )}
          </button>

          {/* Image Preview */}
          {generatedImage && (
            <div className="relative rounded-2xl overflow-hidden border border-zinc-700 max-h-56 bg-zinc-950">
              <img
                src={generatedImage}
                alt="Generated AI Art"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
              <div className="absolute top-2 right-2 px-2 py-0.5 rounded-full bg-black/70 text-[10px] text-pink-300 font-bold border border-pink-500/40">
                {imageSize} UHD Gen
              </div>
            </div>
          )}

          {/* Post Caption & Earnings Badge */}
          <div className="space-y-2 pt-2 border-t border-zinc-800">
            <div>
              <label className="text-xs font-semibold text-zinc-300 block mb-1">
                कैप्शन (Post Caption):
              </label>
              <input
                type="text"
                id="input-post-caption"
                value={caption}
                onChange={(e) => setCaption(e.target.value)}
                className="w-full bg-zinc-900 border border-zinc-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-pink-500"
                placeholder="पोस्ट का विवरण लिखें..."
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-zinc-300 block mb-1">
                कमाई का बैज (Earnings Proof Badge):
              </label>
              <input
                type="text"
                id="input-post-earnings-badge"
                value={earningsBadge}
                onChange={(e) => setEarningsBadge(e.target.value)}
                className="w-full bg-zinc-900 border border-zinc-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-pink-500"
                placeholder="उदा: ₹15,000 क्रेडिटेड या ₹5,000 प्रोजेक्ट"
              />
            </div>
          </div>

          {/* Final Submit Button */}
          <button
            type="button"
            id="btn-publish-post"
            onClick={handleSubmitPost}
            className="w-full py-3 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-950 transition-all active:scale-98 cursor-pointer"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>AI कमाई फीड पर शेयर करें</span>
          </button>
        </div>
      </div>
    </div>
  );
};
