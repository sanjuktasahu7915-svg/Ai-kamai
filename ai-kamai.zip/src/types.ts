export interface Creator {
  id: string;
  name: string;
  handle: string;
  avatar: string;
  location: string;
  bio: string;
  verified: boolean;
  isOnline: boolean;
  earningsThisMonth: number;
  followers: string;
  expertise: string;
  audioCallPrice: number; // ₹1
  videoCallPrice: number; // ₹1
  rating: number;
  totalCallsCompleted: number;
  specialtyChips: string[];
}

export interface Story {
  id: string;
  creatorId: string;
  creatorName: string;
  creatorAvatar: string;
  mediaUrl: string;
  caption: string;
  timestamp: string;
  earningsShowcase?: string;
  isViewed?: boolean;
}

export interface CommentItem {
  id: string;
  userName: string;
  userAvatar: string;
  text: string;
  timestamp: string;
  likes: number;
}

export interface Post {
  id: string;
  creatorId: string;
  creatorName: string;
  creatorHandle: string;
  creatorAvatar: string;
  location: string;
  postImage: string;
  caption: string;
  likes: number;
  commentsCount: number;
  isLiked: boolean;
  isSaved: boolean;
  callPrice: number; // ₹1
  timestamp: string;
  comments: CommentItem[];
  earningsBadge?: string;
  tags?: string[];
}

export interface ChatMessage {
  id: string;
  sender: "user" | "creator" | "system";
  text: string;
  timestamp: string;
  mediaUrl?: string;
  isAudio?: boolean;
  audioDuration?: string;
}

export interface ChatConversation {
  id: string;
  creator: Creator;
  lastMessage: string;
  lastTimestamp: string;
  unreadCount: number;
  messages: ChatMessage[];
}

export interface Transaction {
  id: string;
  type: "call_unlock" | "wallet_recharge" | "earning_withdrawal" | "referral_bonus";
  amount: number;
  status: "success" | "pending" | "failed";
  title: string;
  subtitle: string;
  timestamp: string;
  method: "UPI" | "Wallet" | "GPay" | "PhonePe" | "Paytm" | "Card";
  referenceId: string;
  callType?: "audio" | "video";
}

export interface ActiveCallState {
  isActive: boolean;
  type: "audio" | "video";
  creator: Creator | null;
  status: "calling" | "connected" | "ended";
  durationSeconds: number;
  isMuted: boolean;
  isCameraOff: boolean;
  isSpeakerOn: boolean;
  isAIAssistantActive: boolean;
}
