/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { Header } from "./components/Header";
import { StoriesBar } from "./components/StoriesBar";
import { StoryViewer } from "./components/StoryViewer";
import { PostCard } from "./components/PostCard";
import { UnlockCallModal } from "./components/UnlockCallModal";
import { CallScreen } from "./components/CallScreen";
import { SmsChatModal } from "./components/SmsChatModal";
import { WalletModal } from "./components/WalletModal";
import { CreatePostModal } from "./components/CreatePostModal";
import { ExploreCallHub } from "./components/ExploreCallHub";
import { BottomNav } from "./components/BottomNav";
import {
  CREATORS,
  STORIES,
  INITIAL_POSTS,
  INITIAL_CHATS,
  INITIAL_TRANSACTIONS,
} from "./data/mockData";
import { Creator, Post, Story, ChatConversation, Transaction } from "./types";
import { Sparkles, PhoneCall, Plus, Download, Smartphone } from "lucide-react";
import { InstallAppModal } from "./components/InstallAppModal";
import { OfflineIndicator } from "./components/OfflineIndicator";

export default function App() {
  const [posts, setPosts] = useState<Post[]>(INITIAL_POSTS);
  const [stories, setStories] = useState<Story[]>(STORIES);
  const [creators] = useState<Creator[]>(CREATORS);
  const [chats, setChats] = useState<ChatConversation[]>(INITIAL_CHATS);
  const [transactions, setTransactions] = useState<Transaction[]>(INITIAL_TRANSACTIONS);

  const [walletBalance, setWalletBalance] = useState<number>(35);
  const [earningsBalance, setEarningsBalance] = useState<number>(550);

  // Modals and Active Views
  const [currentTab, setCurrentTab] = useState<"home" | "explore" | "wallet" | "chat">("home");
  const [activeStory, setActiveStory] = useState<Story | null>(null);
  const [isInstallModalOpen, setIsInstallModalOpen] = useState<boolean>(false);
  const [unlockCallCreator, setUnlockCallCreator] = useState<{
    creator: Creator;
    callType: "audio" | "video";
  } | null>(null);
  const [activeCall, setActiveCall] = useState<{
    creator: Creator;
    callType: "audio" | "video";
  } | null>(null);

  const [isChatOpen, setIsChatOpen] = useState(false);
  const [activeChatId, setActiveChatId] = useState<string>("chat_riya");
  const [isWalletOpen, setIsWalletOpen] = useState(false);
  const [isCreatePostOpen, setIsCreatePostOpen] = useState(false);

  // Calculate unread count
  const unreadMessagesCount = chats.reduce((acc, c) => acc + c.unreadCount, 0);

  // Handlers for ₹1 Call flow
  const handleOpenUnlockModal = (creator: Creator, callType: "audio" | "video" = "video") => {
    setUnlockCallCreator({ creator, callType });
  };

  const handlePaymentSuccess = (
    creator: Creator,
    callType: "audio" | "video",
    paymentMethod: "Wallet" | "UPI" | "GPay" | "PhonePe" | "Paytm" | "Card"
  ) => {
    // Deduct ₹1 if paid from wallet
    if (paymentMethod === "Wallet") {
      setWalletBalance((prev) => Math.max(0, prev - 1));
    }

    // Add transaction record
    const newTx: Transaction = {
      id: "TXN_" + Math.random().toString(36).substring(2, 8).toUpperCase(),
      type: "call_unlock",
      amount: 1,
      status: "success",
      title: `₹1 ${callType === "video" ? "वीडियो कॉल" : "ऑडियो कॉल"} अनलॉक`,
      subtitle: `${creator.handle} के साथ 1-on-1 सेशन`,
      timestamp: "अभी",
      method: paymentMethod,
      referenceId: "CALL/" + Date.now().toString().slice(-6),
      callType,
    };
    setTransactions((prev) => [newTx, ...prev]);

    // Close unlock modal & open call screen
    setUnlockCallCreator(null);
    setActiveCall({ creator, callType });
  };

  const handleEndCall = () => {
    setActiveCall(null);
  };

  // Handlers for Chat
  const handleOpenChat = (creator?: Creator) => {
    if (creator) {
      const existing = chats.find((c) => c.creator.id === creator.id);
      if (existing) {
        setActiveChatId(existing.id);
      } else {
        // Create new thread
        const newChat: ChatConversation = {
          id: "chat_" + creator.id,
          creator,
          lastMessage: "बातचीत शुरू करें",
          lastTimestamp: "अभी",
          unreadCount: 0,
          messages: [
            {
              id: "msg_init_" + Date.now(),
              sender: "creator",
              text: `नमस्ते! मैं ${creator.name} हूँ। आप मुझसे AI कमाई के बारे में कोई भी सवाल पूछ सकते हैं या ₹1 में सीधे कॉल कर सकते हैं!`,
              timestamp: "अभी",
            },
          ],
        };
        setChats((prev) => [newChat, ...prev]);
        setActiveChatId(newChat.id);
      }
    }
    setIsChatOpen(true);
  };

  // Handlers for Post Interactions
  const handleLikeToggle = (postId: string) => {
    setPosts((prev) =>
      prev.map((p) =>
        p.id === postId
          ? {
              ...p,
              isLiked: !p.isLiked,
              likes: p.isLiked ? p.likes - 1 : p.likes + 1,
            }
          : p
      )
    );
  };

  const handleSaveToggle = (postId: string) => {
    setPosts((prev) =>
      prev.map((p) => (p.id === postId ? { ...p, isSaved: !p.isSaved } : p))
    );
  };

  const handleAddComment = (postId: string, text: string) => {
    setPosts((prev) =>
      prev.map((p) =>
        p.id === postId
          ? {
              ...p,
              commentsCount: p.commentsCount + 1,
              comments: [
                ...p.comments,
                {
                  id: "comm_" + Date.now(),
                  userName: "you.earning",
                  userAvatar:
                    "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80",
                  text,
                  timestamp: "अभी",
                  likes: 0,
                },
              ],
            }
          : p
      )
    );
  };

  const handlePostCreated = (newPost: Post) => {
    setPosts((prev) => [newPost, ...prev]);
    // Also earn bonus for creating an AI post!
    setEarningsBalance((prev) => prev + 50);
  };

  // Handlers for Wallet
  const handleAddMoney = (
    amount: number,
    method: "UPI" | "GPay" | "PhonePe" | "Paytm" | "Card"
  ) => {
    setWalletBalance((prev) => prev + amount);
    const newTx: Transaction = {
      id: "TXN_" + Math.random().toString(36).substring(2, 8).toUpperCase(),
      type: "wallet_recharge",
      amount,
      status: "success",
      title: `वॉलेट में ₹${amount} जोड़े गए`,
      subtitle: `${method} द्वारा भुगतान`,
      timestamp: "अभी",
      method,
      referenceId: "UPI/REC/" + Date.now().toString().slice(-6),
    };
    setTransactions((prev) => [newTx, ...prev]);
  };

  const handleWithdraw = (amount: number, upiId: string) => {
    setEarningsBalance((prev) => Math.max(0, prev - amount));
    const newTx: Transaction = {
      id: "TXN_" + Math.random().toString(36).substring(2, 8).toUpperCase(),
      type: "earning_withdrawal",
      amount,
      status: "success",
      title: `₹${amount} की निकासी सफल`,
      subtitle: `UPI (${upiId}) को ट्रांसफर्ड`,
      timestamp: "अभी",
      method: "UPI",
      referenceId: "WTH/" + Date.now().toString().slice(-6),
    };
    setTransactions((prev) => [newTx, ...prev]);
  };

  return (
    <div id="app-root-container" className="min-h-screen bg-[#09090b] text-white flex flex-col font-['Plus_Jakarta_Sans',sans-serif]">
      {/* Offline Status Toast */}
      <OfflineIndicator />

      {/* Top Header */}
      <Header
        walletBalance={walletBalance}
        unreadCount={unreadMessagesCount}
        onOpenWallet={() => setIsWalletOpen(true)}
        onOpenChat={() => setIsChatOpen(true)}
        onOpenCreate={() => setIsCreatePostOpen(true)}
        onHomeClick={() => setCurrentTab("home")}
        onOpenInstall={() => setIsInstallModalOpen(true)}
      />

      {/* Main Content Area based on Tab */}
      <main id="app-main-content" className="flex-1 pb-20">
        {currentTab === "home" && (
          <div className="max-w-2xl mx-auto">
            {/* Top Stories Bar */}
            <StoriesBar
              stories={stories}
              onSelectStory={(story) => setActiveStory(story)}
              onAddStory={() => setIsCreatePostOpen(true)}
            />

            {/* App Download / Install Quick Banner */}
            <div className="mx-3.5 mt-2 mb-1 p-3 rounded-2xl bg-gradient-to-r from-purple-950/80 via-pink-950/70 to-zinc-900 border border-purple-600/40 flex items-center justify-between shadow-xl">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-purple-600 to-pink-600 text-white flex items-center justify-center shadow-md shadow-purple-950">
                  <Smartphone className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <p className="text-xs font-black text-white">
                      AI कमाई ऐप डाउनलोड करें
                    </p>
                    <span className="px-1.5 py-0.2 bg-gradient-to-r from-pink-500 to-rose-500 text-white text-[9px] font-black rounded-full">
                      PWA
                    </span>
                  </div>
                  <p className="text-[10px] text-purple-200">
                    सीधे फोन की होम स्क्रीन पर असली ऐप की तरह इंस्टॉल करें
                  </p>
                </div>
              </div>
              <button
                type="button"
                id="btn-banner-install-app"
                onClick={() => setIsInstallModalOpen(true)}
                className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white font-extrabold text-xs transition-transform active:scale-95 cursor-pointer shadow-md shadow-purple-950 flex items-center gap-1"
              >
                <Download className="w-3.5 h-3.5" />
                <span>डाउनलोड</span>
              </button>
            </div>

            {/* ₹1 Call Quick Alert Banner */}
            <div className="mx-3.5 my-3 p-3 rounded-2xl bg-gradient-to-r from-emerald-950/70 via-teal-950/70 to-zinc-900 border border-emerald-500/40 flex items-center justify-between shadow-lg">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30">
                  <PhoneCall className="w-4 h-4" />
                </div>
                <div>
                  <p className="text-xs font-bold text-white flex items-center gap-1.5">
                    <span>₹1 में ऑडियो या वीडियो कॉल करें</span>
                    <span className="px-1.5 py-0.2 bg-emerald-500 text-zinc-950 text-[9px] font-black rounded">
                      लाइव
                    </span>
                  </p>
                  <p className="text-[10px] text-zinc-300">
                    किसी भी पोस्ट पर <span className="text-emerald-400 font-semibold">📞 ₹1</span> दबाएं और तुरंत सीखें
                  </p>
                </div>
              </div>
              <button
                type="button"
                id="btn-banner-explore-calls"
                onClick={() => setCurrentTab("explore")}
                className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition-colors cursor-pointer shadow-sm shadow-emerald-950"
              >
                देखें
              </button>
            </div>

            {/* Posts Feed */}
            <div className="space-y-1">
              {posts.map((post) => {
                const creator = creators.find((c) => c.id === post.creatorId);
                return (
                  <PostCard
                    key={post.id}
                    post={post}
                    creator={creator}
                    onCallClick={(cr, type) => handleOpenUnlockModal(cr, type || "video")}
                    onOpenChat={(cr) => handleOpenChat(cr)}
                    onLikeToggle={handleLikeToggle}
                    onSaveToggle={handleSaveToggle}
                    onAddComment={handleAddComment}
                  />
                );
              })}
            </div>
          </div>
        )}

        {currentTab === "explore" && (
          <ExploreCallHub
            creators={creators}
            onCallCreator={(creator, callType) => handleOpenUnlockModal(creator, callType)}
            onChatCreator={(creator) => handleOpenChat(creator)}
          />
        )}

        {currentTab === "wallet" && (
          <div className="max-w-xl mx-auto p-4">
            <div className="p-4 rounded-3xl bg-[#121216] border border-zinc-800 shadow-xl space-y-4">
              <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
                <h2 className="text-base font-bold text-white">पेमेंट मेथड & वॉलेट</h2>
                <span className="text-xs text-emerald-400 font-semibold">
                  सुरक्षित पेमेंट हब
                </span>
              </div>
              <p className="text-xs text-zinc-400">
                वॉलेट में पैसे जोड़ने, ₹1 कॉल्स अनलॉक करने या कमाई निकालने के लिए नीचे दिए गए बटन पर टैप करें:
              </p>
              <button
                type="button"
                onClick={() => setIsWalletOpen(true)}
                className="w-full py-3 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-950 transition-all cursor-pointer"
              >
                <span>संपूर्ण वॉलेट व पेमेंट डैशबोर्ड खोलें</span>
              </button>
            </div>
          </div>
        )}

        {currentTab === "chat" && (
          <div className="max-w-xl mx-auto p-4">
            <div className="p-4 rounded-3xl bg-[#121216] border border-zinc-800 shadow-xl space-y-4">
              <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
                <h2 className="text-base font-bold text-white">एसएमएस व डीएम चैटिंग</h2>
                <span className="text-xs text-pink-400 font-semibold">
                  24/7 सक्रिय
                </span>
              </div>
              <p className="text-xs text-zinc-400">
                AI कमाई मेंटर्स और क्रिएटर्स से चैट पर सवाल पूछने या लाइव बात करने के लिए चैट बॉक्स खोलें:
              </p>
              <button
                type="button"
                onClick={() => setIsChatOpen(true)}
                className="w-full py-3 rounded-2xl bg-gradient-to-r from-pink-600 to-rose-600 hover:from-pink-500 hover:to-rose-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-pink-950 transition-all cursor-pointer"
              >
                <span>चैटिंग विंडो खोलें ({chats.length} वार्तालाप)</span>
              </button>
            </div>
          </div>
        )}
      </main>

      {/* Bottom Navigation Bar */}
      <BottomNav
        currentTab={currentTab}
        unreadMessagesCount={unreadMessagesCount}
        walletBalance={walletBalance}
        onSelectTab={(tab) => {
          if (tab === "wallet") {
            setIsWalletOpen(true);
          } else if (tab === "chat") {
            setIsChatOpen(true);
          } else {
            setCurrentTab(tab);
          }
        }}
        onOpenCreate={() => setIsCreatePostOpen(true)}
      />

      {/* Story Viewer Modal */}
      {activeStory && (
        <StoryViewer
          story={activeStory}
          creator={creators.find((c) => c.id === activeStory.creatorId)}
          onClose={() => setActiveStory(null)}
          onCallCreator={(cr) => handleOpenUnlockModal(cr, "video")}
        />
      )}

      {/* ₹1 Call Unlock Payment Modal */}
      {unlockCallCreator && (
        <UnlockCallModal
          creator={unlockCallCreator.creator}
          walletBalance={walletBalance}
          initialCallType={unlockCallCreator.callType}
          onClose={() => setUnlockCallCreator(null)}
          onPaymentSuccess={handlePaymentSuccess}
        />
      )}

      {/* Active Audio or Video Call Screen */}
      {activeCall && (
        <CallScreen
          creator={activeCall.creator}
          callType={activeCall.callType}
          onEndCall={handleEndCall}
          onOpenChatWithCreator={(cr) => {
            handleOpenChat(cr);
          }}
        />
      )}

      {/* SMS Chatting Modal (Multi-turn Gemini Chat) */}
      {isChatOpen && (
        <SmsChatModal
          conversations={chats}
          activeConversationId={activeChatId}
          onClose={() => setIsChatOpen(false)}
          onCallCreator={(cr, type) => {
            setIsChatOpen(false);
            handleOpenUnlockModal(cr, type || "video");
          }}
        />
      )}

      {/* Wallet & Payment Methods Modal */}
      {isWalletOpen && (
        <WalletModal
          walletBalance={walletBalance}
          earningsBalance={earningsBalance}
          transactions={transactions}
          onClose={() => setIsWalletOpen(false)}
          onAddMoney={handleAddMoney}
          onWithdraw={handleWithdraw}
        />
      )}

      {/* Create AI Post & Image Generation Modal (1K, 2K, 4K) */}
      {isCreatePostOpen && (
        <CreatePostModal
          onClose={() => setIsCreatePostOpen(false)}
          onPostCreated={handlePostCreated}
        />
      )}

      {/* App Install / Download Modal */}
      <InstallAppModal
        isOpen={isInstallModalOpen}
        onClose={() => setIsInstallModalOpen(false)}
      />
    </div>
  );
}
