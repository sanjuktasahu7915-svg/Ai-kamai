import fs from 'fs';
import zlib from 'zlib';

function crc32(buf) {
  let crc = 0xffffffff;
  for (let i = 0; i < buf.length; i++) {
    const byte = buf[i];
    for (let j = 0; j < 8; j++) {
      const bit = (crc ^ (byte >> j)) & 1;
      crc = (crc >>> 1) ^ (bit ? 0xedb88320 : 0);
    }
  }
  return (crc ^ 0xffffffff) >>> 0;
}

function makeChunk(type, data) {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length, 0);
  const typeBuf = Buffer.from(type, 'ascii');
  const body = Buffer.concat([typeBuf, data]);
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crc32(body), 0);
  return Buffer.concat([len, body, crc]);
}

function createPng(width, height, drawFn) {
  const sig = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);

  // IHDR
  const ihdrData = Buffer.alloc(13);
  ihdrData.writeUInt32BE(width, 0);
  ihdrData.writeUInt32BE(height, 4);
  ihdrData[8] = 8; // 8 bits per channel
  ihdrData[9] = 6; // RGBA
  ihdrData[10] = 0; // compression
  ihdrData[11] = 0; // filter
  ihdrData[12] = 0; // interlace
  const ihdr = makeChunk('IHDR', ihdrData);

  // Raw image data with filter byte 0 at start of each row
  const rowStride = width * 4 + 1;
  const rawData = Buffer.alloc(height * rowStride);

  for (let y = 0; y < height; y++) {
    const rowOffset = y * rowStride;
    rawData[rowOffset] = 0; // Filter: None
    for (let x = 0; x < width; x++) {
      const pixelOffset = rowOffset + 1 + x * 4;
      const [r, g, b, a] = drawFn(x, y, width, height);
      rawData[pixelOffset] = r;
      rawData[pixelOffset + 1] = g;
      rawData[pixelOffset + 2] = b;
      rawData[pixelOffset + 3] = a;
    }
  }

  const compressed = zlib.deflateSync(rawData);
  const idat = makeChunk('IDAT', compressed);
  const iend = makeChunk('IEND', Buffer.alloc(0));

  return Buffer.concat([sig, ihdr, idat, iend]);
}

// Icon design:
// Deep rich violet-to-magenta gradient background (#180b2c to #5f259f / #ec4899)
// Rounded squircle with gold coin / PhonePe purple accent & call/rupee badge
function drawIcon(x, y, w, h, isMaskable = false) {
  const nx = x / w;
  const ny = y / h;
  const cx = 0.5;
  const cy = 0.5;
  const dx = nx - cx;
  const dy = ny - cy;
  const dist = Math.sqrt(dx * dx + dy * dy);

  // Corner rounding for standard icon (maskable is full bleed)
  if (!isMaskable) {
    const cornerRadius = 0.22;
    const qx = Math.max(0, Math.abs(dx) - (0.5 - cornerRadius));
    const qy = Math.max(0, Math.abs(dy) - (0.5 - cornerRadius));
    const distCorner = Math.sqrt(qx * qx + qy * qy);
    if (distCorner > cornerRadius) {
      return [0, 0, 0, 0]; // Transparent outside squircle
    }
  }

  // Base background gradient: Top-left #7928ca to bottom-right #5f259f
  const grad = (nx + ny) / 2;
  let r = Math.round(95 + 60 * grad);
  let g = Math.round(37 + 10 * (1 - grad));
  let b = Math.round(159 + 50 * (1 - grad));

  // Outer glowing ring
  if (dist > 0.32 && dist < 0.37) {
    const ringIntensity = Math.sin(((dist - 0.32) / 0.05) * Math.PI);
    r = Math.min(255, r + Math.round(120 * ringIntensity));
    g = Math.min(255, g + Math.round(60 * ringIntensity));
    b = Math.min(255, b + Math.round(180 * ringIntensity));
  }

  // Center badge circle (gold/amber badge with ₹ & AI)
  if (dist < 0.28) {
    const centerGrad = (nx - 0.22 + ny - 0.22) / 0.56;
    // Golden gradient for ₹ AI earning
    r = Math.round(245 - 20 * centerGrad);
    g = Math.round(158 - 30 * centerGrad);
    b = Math.round(11 + 20 * centerGrad);

    // Darker inner border
    if (dist > 0.26) {
      r = Math.round(r * 0.7);
      g = Math.round(g * 0.7);
      b = Math.round(b * 0.7);
    }
  }

  // Simple clean glyph inside: Rupee horizontal bar & vertical curve
  // Normalized in center (-0.12 to +0.12)
  if (Math.abs(dx) < 0.12 && Math.abs(dy) < 0.14) {
    // Top bar of Rupee
    if (dy > -0.11 && dy < -0.07 && Math.abs(dx) < 0.10) {
      return [255, 255, 255, 255];
    }
    // Second bar
    if (dy > -0.05 && dy < -0.01 && Math.abs(dx) < 0.09) {
      return [255, 255, 255, 255];
    }
    // Vertical stem & upper loop
    if (dx > -0.07 && dx < -0.03 && dy > -0.11 && dy < 0.10) {
      return [255, 255, 255, 255];
    }
    // Loop
    if (dx >= -0.03 && dx < 0.05 && dy > -0.07 && dy < 0.02) {
      const loopDist = Math.hypot(dx - 0.01, dy - (-0.025));
      if (loopDist < 0.045 && loopDist > 0.015) {
        return [255, 255, 255, 255];
      }
    }
    // Slash / leg of rupee
    if (dy >= 0.02 && dy < 0.10) {
      const targetX = -0.03 + (dy - 0.02) * 1.0;
      if (Math.abs(dx - targetX) < 0.025) {
        return [255, 255, 255, 255];
      }
    }
  }

  return [r, g, b, 255];
}

if (!fs.existsSync('./public')) {
  fs.mkdirSync('./public', { recursive: true });
}

// 192x192
console.log('Generating pwa-192x192.png...');
const pwa192 = createPng(192, 192, (x, y, w, h) => drawIcon(x, y, w, h, false));
fs.writeFileSync('./public/pwa-192x192.png', pwa192);

// 512x512
console.log('Generating pwa-512x512.png...');
const pwa512 = createPng(512, 512, (x, y, w, h) => drawIcon(x, y, w, h, false));
fs.writeFileSync('./public/pwa-512x512.png', pwa512);

// 512x512 maskable (safe margins)
console.log('Generating pwa-maskable-512x512.png...');
const pwaMaskable = createPng(512, 512, (x, y, w, h) => drawIcon(x, y, w, h, true));
fs.writeFileSync('./public/pwa-maskable-512x512.png', pwaMaskable);

// Apple touch icon (180x180)
console.log('Generating apple-touch-icon.png...');
const appleIcon = createPng(180, 180, (x, y, w, h) => drawIcon(x, y, w, h, false));
fs.writeFileSync('./public/apple-touch-icon.png', appleIcon);

// Favicon 64x64
console.log('Generating favicon.png...');
const favicon = createPng(64, 64, (x, y, w, h) => drawIcon(x, y, w, h, false));
fs.writeFileSync('./public/favicon.ico', favicon);

console.log('All icons generated successfully!');
