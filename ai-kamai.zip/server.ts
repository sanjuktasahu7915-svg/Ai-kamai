import express from "express";
import path from "path";
import dotenv from "dotenv";
import { GoogleGenAI } from "@google/genai";
import { createServer as createViteServer } from "vite";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "15mb" }));

// Lazy initialize Gemini client
let aiClient: GoogleGenAI | null = null;
function getAi(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return null;
  if (!aiClient) {
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

// Health check endpoint
app.get("/api/health", (req, res) => {
  res.json({
    status: "ok",
    app: "AI कमाई",
    hasApiKey: !!process.env.GEMINI_API_KEY,
  });
});

// Gemini Multi-turn Chat Endpoint (एसएमएस चैटिंग / AI मेंटोर)
app.post("/api/gemini/chat", async (req, res) => {
  try {
    const { messages, creatorName, creatorRole, modelChoice } = req.body;
    const ai = getAi();

    const selectedModel = modelChoice || "gemini-3.5-flash";

    const systemPrompt = `आप "AI कमाई" ऐप के एक प्रसिद्ध क्रिएटर व विशेषज्ञ "${creatorName || "AI कमाई मेंटोर"}" हैं (${creatorRole || "AI से पैसे कमाने के एक्सपर्ट"}).
उपयोगकर्ता आपसे इंस्टाग्राम जैसे डायरेक्ट मैसेज (SMS चैटिंग) में चैट कर रहा है।
आपका उद्देश्य:
- यूज़र को AI से पैसे कमाने के व्यावहारिक और आसान तरीके बताना (जैसे ChatGPT से यूट्यूब स्क्रिप्ट्स, फ्रीलांसिंग, प्रॉम्प्ट इंजीनियरिंग, AI इमेज व थंबनेल डिजाइन, वॉयसओवर, ऑटोमेशन)।
- दोस्ताना, प्रेरणादायक और मददगार अंदाज़ में बात करना।
- मुख्य रूप से आसान हिंदी / हिंग्लिश (Hindi/Hinglish) में जवाब देना ताकि भारत के हर वर्ग को समझ आए।
- अगर यूज़र ₹1 में ऑडियो या वीडियो कॉल के बारे में पूछे, तो बताएं कि वे प्रोफाइल या ऊपर दिए गए '📞 ₹1' बटन से तुरंत 1-on-1 लाइव कॉल शुरू कर सकते हैं।
- जवाब 2 से 4 संक्षिप्त पैराग्राफ या आसान बुलेट पॉइंट्स में रखें।`;

    if (!ai) {
      // Fallback friendly simulation if API key isn't injected yet
      return res.json({
        reply: `नमस्ते! मैं ${creatorName || "AI कमाई मेंटोर"} हूँ। AI से घर बैठे कमाई करने के कई तरीके हैं! जैसे: 1. क्लाइंट्स के लिए यूट्यूब/रील्स स्क्रिप्ट लिखना, 2. AI थंबनेल और लोगो डिज़ाइन करना, 3. प्रॉम्प्ट्स बेचकर फ्रीलांसिंग करना। यदि आपको पर्सनल गाइडेंस चाहिए, तो आप सिर्फ ₹1 में मुझसे 1-on-1 ऑडियो या वीडियो कॉल भी कर सकते हैं! क्या आप कोई खास फील्ड सीखना चाहते हैं?`,
        modelUsed: "offline-assistant",
      });
    }

    // Convert messages array to contents
    const contents = (messages || []).map((m: any) => ({
      role: m.sender === "user" ? "user" : "model",
      parts: [{ text: m.text }],
    }));

    if (contents.length === 0) {
      contents.push({
        role: "user",
        parts: [{ text: "नमस्ते! AI से पैसे कमाने का सबसे आसान तरीका क्या है?" }],
      });
    }

    const response = await ai.models.generateContent({
      model: selectedModel,
      contents,
      config: {
        systemInstruction: systemPrompt,
        temperature: 0.7,
      },
    });

    const replyText = response.text || "नमस्ते! AI कमाई में आपका स्वागत है। मैं आपकी क्या मदद कर सकता हूँ?";
    res.json({ reply: replyText, modelUsed: selectedModel });
  } catch (error: any) {
    console.error("Error in /api/gemini/chat:", error);
    res.status(500).json({
      error: error.message || "Gemini API call failed",
      fallbackReply: "नमस्ते! नेटवर्क में थोड़ी रुकावट आ रही है, पर आप AI से कंटेंट राइटिंग, वॉइसओवर और इमेज जनरेशन सीखकर हर दिन ₹1000-₹3000 कमा सकते हैं।",
    });
  }
});

// Gemini Image Generation Endpoint (1K, 2K, 4K affordance)
app.post("/api/gemini/generate-image", async (req, res) => {
  try {
    const { prompt, imageSize = "1K", aspectRatio = "1:1" } = req.body;
    const ai = getAi();

    if (!ai) {
      return res.status(400).json({
        error: "GEMINI_API_KEY environment variable is not configured.",
      });
    }

    // Attempt generation with gemini-3-pro-image-preview as requested in feature prompt
    // (fallback to gemini-3.1-flash-image if pro needs different quota)
    let imageUrl = "";
    try {
      const response = await ai.models.generateContent({
        model: "gemini-3-pro-image-preview",
        contents: {
          parts: [{ text: prompt || "A high quality modern 3D illustration of earning money online with artificial intelligence in India" }],
        },
        config: {
          imageConfig: {
            aspectRatio: aspectRatio as any,
            imageSize: imageSize as any,
          },
        },
      });

      const parts = response.candidates?.[0]?.content?.parts || [];
      for (const part of parts) {
        if (part.inlineData?.data) {
          imageUrl = `data:${part.inlineData.mimeType || "image/png"};base64,${part.inlineData.data}`;
          break;
        }
      }
    } catch (modelErr: any) {
      console.warn("Primary image model failed, trying gemini-3.1-flash-image:", modelErr.message);
      const fallbackResponse = await ai.models.generateContent({
        model: "gemini-3.1-flash-image",
        contents: {
          parts: [{ text: prompt }],
        },
        config: {
          imageConfig: {
            aspectRatio: aspectRatio as any,
            imageSize: imageSize as any,
          },
        },
      });

      const parts = fallbackResponse.candidates?.[0]?.content?.parts || [];
      for (const part of parts) {
        if (part.inlineData?.data) {
          imageUrl = `data:${part.inlineData.mimeType || "image/png"};base64,${part.inlineData.data}`;
          break;
        }
      }
    }

    if (!imageUrl) {
      throw new Error("No image data returned from model");
    }

    res.json({ imageUrl, size: imageSize, prompt });
  } catch (error: any) {
    console.error("Error in /api/gemini/generate-image:", error);
    res.status(500).json({
      error: error.message || "Image generation failed",
    });
  }
});

// ₹1 Payment & Call Session Verification endpoint
app.post("/api/payments/process-call-fee", (req, res) => {
  const { creatorId, callType, paymentMethod, amount = 1 } = req.body;
  const txnId = "TXN_" + Math.random().toString(36).substring(2, 9).toUpperCase();
  const timestamp = new Date().toISOString();

  res.json({
    success: true,
    amount,
    currency: "INR",
    txnId,
    timestamp,
    callSessionId: "CALL_" + Math.random().toString(36).substring(2, 8).toUpperCase(),
    callType, // "audio" | "video"
    creatorId,
    message: `₹${amount} भुगतान सफल! ${callType === "video" ? "वीडियो कॉल" : "ऑडियो कॉल"} सक्रिय किया गया।`,
  });
});

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`AI कमाई Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
